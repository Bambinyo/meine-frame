#!/bin/bash
# Construit et installe l'application « Ma Frame » dans ~/Applications
set -e
cd "$HOME/frame-tv"
# Messages en français, ou en allemand si Ma Frame est réglée en allemand
DE=""; grep -q '"langue": *"de"' config.json 2>/dev/null && DE=1
dire(){ if [ -n "$DE" ]; then echo "$2"; else echo "$1"; fi; }
NOM="Ma Frame"; [ -n "$DE" ] && NOM="Meine FRAME"
APP="$HOME/Applications/$NOM.app"
dire "1/4 Arrêt de l'ancienne version…" "3/4 Alte Version wird beendet …"
pkill -f "frame-tv/app.py" 2>/dev/null || true
pkill -f "$NOM.app/Contents/MacOS" 2>/dev/null || true
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
dire "2/4 Compilation de l'appli (1 minute environ)…" "3/4 App wird gebaut (etwa 1 Minute) …"
swiftc -O app-mac/main.swift -o "$APP/Contents/MacOS/MaFrame"
cp app-mac/Info.plist "$APP/Contents/Info.plist"
/usr/libexec/PlistBuddy -c "Set :CFBundleName $NOM" -c "Set :CFBundleDisplayName $NOM" "$APP/Contents/Info.plist"
dire "2b Service d'arrière-plan…" "3/4 Hintergrunddienst …"
PLIST="$HOME/Library/LaunchAgents/perso.maframe.serveur.plist"
mkdir -p "$HOME/Library/LaunchAgents" "$HOME/frame-tv/.cache"
cat > "$PLIST" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>perso.maframe.serveur</string>
<key>ProgramArguments</key><array>
<string>$HOME/frame-tv/.venv/bin/python</string><string>$HOME/frame-tv/app.py</string><string>--sans-navigateur</string></array>
<key>WorkingDirectory</key><string>$HOME/frame-tv</string>
<key>RunAtLoad</key><true/>
<key>KeepAlive</key><true/>
<key>StandardOutPath</key><string>$HOME/frame-tv/.cache/app.log</string>
<key>StandardErrorPath</key><string>$HOME/frame-tv/.cache/app.log</string>
</dict></plist>
PL
launchctl bootout "gui/$(id -u)/perso.maframe.serveur" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$PLIST"
dire "3/4 Icône…" "4/4 Symbol …"
rm -rf /tmp/i.iconset && mkdir -p /tmp/i.iconset
for s in 16 32 128 256 512; do
  sips -z $s $s web/icone.png --out /tmp/i.iconset/icon_${s}x${s}.png >/dev/null
  sips -z $((s*2)) $((s*2)) web/icone.png --out /tmp/i.iconset/icon_${s}x${s}@2x.png >/dev/null
done
iconutil -c icns /tmp/i.iconset -o "$APP/Contents/Resources/icone.icns"
touch "$APP"
dire "4/4 Lancement…" "4/4 Start …"
killall Dock 2>/dev/null || true
sleep 1
open "$APP"
dire "✅ Ma Frame est installée." "✅ Meine FRAME ist installiert."
