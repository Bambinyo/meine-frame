// Ma Frame — application Mac native (fenêtre WebKit + serveur Python en arrière-plan)
import Cocoa
import WebKit

// Langue choisie dans Ma Frame (Réglages → Langue), enregistrée dans config.json ; français par défaut.
let langueDE: Bool = {
    let url = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("frame-tv/config.json")
    guard let d = try? Data(contentsOf: url), let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else { return false }
    return (j["langue"] as? String) == "de"
}()
func L(_ fr: String, _ de: String) -> String { langueDE ? de : fr }

final class AppDelegate: NSObject, NSApplicationDelegate, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
    var window: NSWindow!
    var web: WKWebView!
    let base = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("frame-tv")
    let adresse = URL(string: "http://localhost:8765/")!

    func applicationDidFinishLaunching(_ notification: Notification) {
        construireMenu()
        let cfg = WKWebViewConfiguration()
        cfg.userContentController.add(self, name: "maframe")
        web = WKWebView(frame: .zero, configuration: cfg)
        web.navigationDelegate = self
        web.uiDelegate = self
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1120, height: 780),
                          styleMask: [.titled, .closable, .miniaturizable, .resizable],
                          backing: .buffered, defer: false)
        window.title = L("Ma Frame", "Meine FRAME")
        window.minSize = NSSize(width: 420, height: 500)
        window.contentView = web
        window.center()
        window.setFrameAutosaveName("MaFrameFenetre")
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        web.loadHTMLString("<body style='font:15px -apple-system;color:#888;display:flex;align-items:center;justify-content:center;height:90vh'>\(L("Démarrage…", "Wird gestartet …"))</body>", baseURL: nil)
        chargerQuandPret(0)
    }

    // Le moteur tourne comme service d'arrière-plan (launchd). Si besoin, on le relance.
    func lancerServeur() {
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/bin/launchctl")
        p.arguments = ["kickstart", "gui/\(getuid())/perso.maframe.serveur"]
        try? p.run()
    }

    func chargerQuandPret(_ essai: Int) {
        var req = URLRequest(url: adresse.appendingPathComponent("api/tache"))
        req.timeoutInterval = 1
        URLSession.shared.dataTask(with: req) { _, rep, _ in
            DispatchQueue.main.async {
                if (rep as? HTTPURLResponse)?.statusCode == 200 {
                    self.web.load(URLRequest(url: self.adresse))
                } else if essai < 80 {
                    if essai == 5 { self.lancerServeur() }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { self.chargerQuandPret(essai + 1) }
                } else {
                    self.web.loadHTMLString("<body style='font:15px -apple-system;padding:40px'>\(L("Ma Frame n’a pas pu démarrer.<br>Détails : ~/frame-tv/.cache/app.log (essaie de relancer l’installation)", "Meine FRAME konnte nicht starten.<br>Details: ~/frame-tv/.cache/app.log (starte die Installation erneut)"))</body>", baseURL: nil)
                }
            }
        }.resume()
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
    func applicationWillTerminate(_ notification: Notification) { desactiverControle() }

    // Boîtes de dialogue JavaScript (alert / confirm / prompt) en version macOS
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let a = NSAlert(); a.messageText = message; a.addButton(withTitle: "OK"); a.runModal(); completionHandler()
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let a = NSAlert(); a.messageText = message
        a.addButton(withTitle: "OK"); a.addButton(withTitle: L("Annuler", "Abbrechen"))
        completionHandler(a.runModal() == .alertFirstButtonReturn)
    }
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        let a = NSAlert(); a.messageText = prompt
        let champ = NSTextField(frame: NSRect(x: 0, y: 0, width: 260, height: 24))
        champ.stringValue = defaultText ?? ""
        a.accessoryView = champ
        a.addButton(withTitle: "OK"); a.addButton(withTitle: L("Annuler", "Abbrechen"))
        a.window.initialFirstResponder = champ
        completionHandler(a.runModal() == .alertFirstButtonReturn ? champ.stringValue : nil)
    }
    // Bouton « Tes photos » : fenêtre de choix de fichiers du Mac (WebKit n'en affiche pas tout seul)
    func webView(_ webView: WKWebView, runOpenPanelWith parameters: WKOpenPanelParameters,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping ([URL]?) -> Void) {
        let p = NSOpenPanel()
        p.allowsMultipleSelection = parameters.allowsMultipleSelection
        p.canChooseDirectories = false
        p.canChooseFiles = true
        p.allowedFileTypes = ["public.image"]
        p.message = L("Choisis les photos à mettre sur la Frame", "Wähle die Fotos für deine Frame")
        p.prompt = L("Choisir", "Auswählen")
        p.beginSheetModal(for: window) { r in completionHandler(r == .OK ? p.urls : nil) }
    }


    // MARK: - Contrôler la TV avec la souris et le clavier du Mac
    var controle = false
    var moniteur: Any?
    var accX = 0.0, accY = 0.0, sourisEnVol = false
    var minuteurSouris: Timer?
    var tampon = ""
    var minuteurTexte: Timer?
    var derniereMolette = Date.distantPast

    func userContentController(_ uc: WKUserContentController, didReceive message: WKScriptMessage) {
        if let m = message.body as? String {
            if m == "controle" { activerControle() } else if m == "liberer" { desactiverControle() }
        }
    }

    func appel(_ chemin: String, _ corps: [String: Any], fin: (() -> Void)? = nil) {
        var req = URLRequest(url: adresse.appendingPathComponent("api/" + chemin))
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try? JSONSerialization.data(withJSONObject: corps)
        req.timeoutInterval = 5
        URLSession.shared.dataTask(with: req) { _, _, _ in DispatchQueue.main.async { fin?() } }.resume()
    }

    func js(_ code: String) { web.evaluateJavaScript(code, completionHandler: nil) }

    @objc func basculerControle() { controle ? desactiverControle() : activerControle() }

    func activerControle() {
        guard !controle else { return }
        controle = true; tampon = ""
        window.acceptsMouseMovedEvents = true
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        // placer le curseur au centre de la fenêtre avant de le figer : les clics restent dans Ma Frame
        if let ecran = NSScreen.screens.first {
            let f = window.frame
            CGWarpMouseCursorPosition(CGPoint(x: f.midX, y: ecran.frame.height - f.midY))
        }
        NSCursor.hide()
        CGAssociateMouseAndMouseCursorPosition(0)
        js("window.modeControle && modeControle(true)")
        moniteur = NSEvent.addLocalMonitorForEvents(matching: [.mouseMoved, .leftMouseDragged, .rightMouseDragged, .leftMouseDown, .rightMouseDown, .scrollWheel, .keyDown]) { [weak self] ev in
            guard let s = self, s.controle else { return ev }
            switch ev.type {
            case .mouseMoved, .leftMouseDragged, .rightMouseDragged:
                s.accX += Double(ev.deltaX); s.accY += Double(ev.deltaY)
            case .leftMouseDown:
                s.appel("souris", ["clic": 1])
            case .rightMouseDown:
                s.appel("telecommande", ["action": "retour"])
            case .scrollWheel:
                let d = ev.scrollingDeltaY
                if abs(d) > 2 && Date().timeIntervalSince(s.derniereMolette) > 0.18 {
                    s.derniereMolette = Date()
                    s.appel("telecommande", ["action": d > 0 ? "page_haut" : "page_bas"])
                }
            case .keyDown:
                if ev.modifierFlags.contains(.command) { return ev }   // ⌘Q, ⌘⇧T… restent au Mac
                s.touche(ev)
            default: break
            }
            return nil
        }
        minuteurSouris = Timer.scheduledTimer(withTimeInterval: 0.03, repeats: true) { [weak self] _ in
            guard let s = self, !s.sourisEnVol else { return }
            let dx = (s.accX * 1.6).rounded(), dy = (s.accY * 1.6).rounded()
            if dx == 0 && dy == 0 { return }
            s.accX -= dx / 1.6; s.accY -= dy / 1.6; s.sourisEnVol = true
            s.appel("souris", ["dx": Int(dx), "dy": Int(dy)]) { s.sourisEnVol = false }
        }
    }

    func desactiverControle() {
        guard controle else { return }
        controle = false
        if let m = moniteur { NSEvent.removeMonitor(m); moniteur = nil }
        minuteurSouris?.invalidate(); minuteurTexte?.invalidate()
        CGAssociateMouseAndMouseCursorPosition(1)
        NSCursor.unhide()
        js("window.modeControle && modeControle(false)")
    }

    func envoyerTampon(valider: Bool) {
        appel("texte", ["texte": tampon, "valider": valider])
    }

    var lecture = true
    func touche(_ ev: NSEvent) {
        if ev.modifierFlags.contains(.option) {                                 // raccourcis ⌥
            switch ev.keyCode {
            case 0:  appel("telecommande", ["action": "home"])                   // ⌥A
            case 49: lecture.toggle(); appel("telecommande", ["action": lecture ? "lecture" : "pause"])   // ⌥Espace
            case 126: appel("telecommande", ["action": "vol_plus"])             // ⌥↑
            case 125: appel("telecommande", ["action": "vol_moins"])            // ⌥↓
            case 46: appel("telecommande", ["action": "muet"])                   // ⌥M
            case 15: appel("telecommande", ["action": "art_on"])                 // ⌥R
            default: break
            }
            return
        }
        switch ev.keyCode {
        case 53: desactiverControle()                                            // Échap : rendre la main
        case 126: appel("telecommande", ["action": "haut"])
        case 125: appel("telecommande", ["action": "bas"])
        case 123: appel("telecommande", ["action": "gauche"])
        case 124: appel("telecommande", ["action": "droite"])
        case 36, 76:                                                             // Entrée
            if tampon.isEmpty { appel("telecommande", ["action": "ok"]) }
            else { minuteurTexte?.invalidate(); envoyerTampon(valider: true); tampon = "" }
        case 51:                                                                 // Effacer
            if tampon.isEmpty { appel("telecommande", ["action": "retour"]) }
            else { tampon.removeLast(); programmerTexte() }
        default:
            if let c = ev.characters, !c.isEmpty, c.unicodeScalars.allSatisfy({ !CharacterSet.controlCharacters.contains($0) }) {
                tampon += c; programmerTexte()
            }
        }
        let t = tampon.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "'", with: "\\'")
        js("window.majTampon && majTampon('\(t)')")
    }

    func programmerTexte() {
        minuteurTexte?.invalidate()
        minuteurTexte = Timer.scheduledTimer(withTimeInterval: 0.15, repeats: false) { [weak self] _ in self?.envoyerTampon(valider: false) }
    }

    func applicationDidResignActive(_ notification: Notification) { desactiverControle() }

    @objc func recharger() { web.reload() }

    func construireMenu() {
        let barre = NSMenu()
        func sousMenu(_ titre: String) -> NSMenu {
            let item = NSMenuItem(); barre.addItem(item)
            let m = NSMenu(title: titre); item.submenu = m; return m
        }
        let app = sousMenu(L("Ma Frame", "Meine FRAME"))
        app.addItem(withTitle: L("Masquer Ma Frame", "Meine FRAME ausblenden"), action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
        app.addItem(NSMenuItem.separator())
        app.addItem(withTitle: L("Quitter Ma Frame", "Meine FRAME beenden"), action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        let edition = sousMenu(L("Édition", "Bearbeiten"))
        edition.addItem(withTitle: L("Annuler", "Widerrufen"), action: Selector(("undo:")), keyEquivalent: "z")
        edition.addItem(NSMenuItem.separator())
        edition.addItem(withTitle: L("Couper", "Ausschneiden"), action: #selector(NSText.cut(_:)), keyEquivalent: "x")
        edition.addItem(withTitle: L("Copier", "Kopieren"), action: #selector(NSText.copy(_:)), keyEquivalent: "c")
        edition.addItem(withTitle: L("Coller", "Einsetzen"), action: #selector(NSText.paste(_:)), keyEquivalent: "v")
        edition.addItem(withTitle: L("Tout sélectionner", "Alles auswählen"), action: #selector(NSText.selectAll(_:)), keyEquivalent: "a")
        let affichage = sousMenu(L("Présentation", "Darstellung"))
        let r = affichage.addItem(withTitle: L("Actualiser", "Neu laden"), action: #selector(recharger), keyEquivalent: "r"); r.target = self
        let tv = sousMenu(L("TV", "Fernseher"))
        let c = tv.addItem(withTitle: L("Contrôler la TV avec la souris et le clavier", "Fernseher mit Maus und Tastatur steuern"), action: #selector(basculerControle), keyEquivalent: "t")
        c.keyEquivalentModifierMask = [.command, .shift]; c.target = self
        let fenetre = sousMenu(L("Fenêtre", "Fenster"))
        fenetre.addItem(withTitle: L("Réduire", "Im Dock ablegen"), action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
        fenetre.addItem(withTitle: L("Fermer", "Schließen"), action: #selector(NSWindow.performClose(_:)), keyEquivalent: "w")
        NSApp.mainMenu = barre
    }
}

let app = NSApplication.shared
let delegue = AppDelegate()
app.delegate = delegue
app.setActivationPolicy(.regular)
app.run()
