#!/usr/bin/env python3
"""Collection pour The Frame : télécharge des œuvres libres de droits (format paysage)
puis les envoie sur la TV.
  python collection.py telecharger   → remplit le dossier « oeuvres »
  python collection.py envoyer       → envoie toutes les images du dossier sur la TV
"""
import json, os, re, subprocess, sys, time, urllib.parse, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "oeuvres")
SAISONS_DIR = os.path.join(HERE, "saisons")
SAISONS = {"5-printemps", "6-ete", "7-automne", "8-hiver", "9-noel"}
def saisons_du_moment(m=None):
    import datetime
    m = m or datetime.date.today().month
    s = {3: "5-printemps", 4: "5-printemps", 5: "5-printemps", 6: "6-ete", 7: "6-ete", 8: "6-ete",
         9: "7-automne", 10: "7-automne", 11: "7-automne"}.get(m, "8-hiver")
    return [s, "9-noel"] if m == 12 else [s]
UA = {"User-Agent": "MaFrame/1.0 (application personnelle, galerie pour TV ; Python-urllib)", "AIC-User-Agent": "FrameTV-perso (usage personnel)"}
PAR_RECHERCHE = 4

THEMES = {
    "1-chefs-doeuvre": [("aic", "Claude Monet"), ("aic", "Vincent van Gogh"), ("commons", '"Johannes Vermeer" painting'), ("commons", '"Gustav Klimt" landscape')],
    "2-estampes-japonaises": [("aic", "Hokusai"), ("aic", "Hiroshige"), ("aic", "Mount Fuji"), ("aic", "cherry blossoms")],
    "3-impressionnistes": [("aic", "Renoir"), ("aic", "Pissarro"), ("aic", "Sisley"), ("aic", "Caillebotte")],
    "4-espace": [("nasa", "James Webb"), ("nasa", "Hubble nebula"), ("nasa", "galaxy")],
    "0-photos-incroyables": [("photo", "mountains"), ("photo", "aurora"), ("photo", "ocean waves"),
        ("photo", "forest fog"), ("photo", "desert dunes"), ("photo", "glacier"), ("photo", "wildlife"),
        ("photo", "Milky Way"), ("photo", "waterfall"), ("photo", "Berlin")],
    "5-printemps": [("aic", "spring landscape"), ("aic", "blossoming orchard"), ("cma", "spring landscape")],
    "6-ete": [("aic", "summer landscape"), ("aic", "beach seaside"), ("cma", "summer landscape")],
    "7-automne": [("aic", "autumn landscape"), ("cma", "autumn landscape")],
    "8-hiver": [("aic", "winter snow landscape"), ("aic", "snow Hiroshige"), ("cma", "winter landscape snow")],
    "9-noel": [("aic", "Christmas"), ("cma", "Christmas"), ("aic", "winter village skating")],
}

def get_json(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.load(r)

def download(url, path):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=90) as r, open(path, "wb") as f:
        f.write(r.read())

def dims(path):
    out = subprocess.run(["sips", "-g", "pixelWidth", "-g", "pixelHeight", path], capture_output=True, text=True).stdout
    w = re.search(r"pixelWidth: (\d+)", out); h = re.search(r"pixelHeight: (\d+)", out)
    return (int(w.group(1)), int(h.group(1))) if w and h else (0, 0)

def clean(s, n=60):
    s = re.sub(r"[^\w\s\-]", "", s or "", flags=re.UNICODE).strip()
    return re.sub(r"\s+", " ", s)[:n] or "sans titre"

# --- Sources : renvoient des tuples (url_image, titre, artiste, source) ---
def aic(q):
    p = urllib.parse.urlencode({"q": q, "query[term][is_public_domain]": "true", "limit": 40,
                                "fields": "id,title,artist_title,image_id,thumbnail"})
    d = get_json(f"https://api.artic.edu/api/v1/artworks/search?{p}")
    base = d.get("config", {}).get("iiif_url", "https://www.artic.edu/iiif/2")
    for a in d.get("data", []):
        t = a.get("thumbnail") or {}
        if a.get("image_id") and t.get("width") and t.get("height") and t["width"] / t["height"] >= 1.15:
            yield f"{base}/{a['image_id']}/full/1686,/0/default.jpg", a.get("title"), a.get("artist_title"), "Art Institute of Chicago"

def cma(q):
    p = urllib.parse.urlencode({"q": q, "has_image": 1, "cc0": 1, "limit": 40})
    for a in get_json(f"https://openaccess-api.clevelandart.org/api/artworks/?{p}").get("data", []):
        imgs = a.get("images") or {}
        im = imgs.get("print") or imgs.get("web") or {}
        w, h = int(im.get("width") or 0), int(im.get("height") or 0)
        if im.get("url") and h and w / h >= 1.15:
            artiste = (a.get("creators") or [{}])[0].get("description", "").split(" (")[0]
            yield im["url"], a.get("title"), artiste, "Cleveland Museum of Art"

def commons(q):
    p = urllib.parse.urlencode({"action": "query", "format": "json", "generator": "search",
        "gsrsearch": f"{q} filetype:bitmap", "gsrnamespace": 6, "gsrlimit": 40,
        "prop": "imageinfo", "iiprop": "url|size", "iiurlwidth": 3840})
    pages = (get_json(f"https://commons.wikimedia.org/w/api.php?{p}").get("query") or {}).get("pages", {})
    for pg in sorted(pages.values(), key=lambda x: x.get("index", 99)):
        ii = (pg.get("imageinfo") or [{}])[0]
        w, h = ii.get("width", 0), ii.get("height", 0)
        if h and w / h >= 1.15 and w >= 1500:
            titre = re.sub(r"^File:|\.\w+$", "", pg.get("title", ""))
            yield ii.get("thumburl") or ii["url"], titre, q.split(" ")[0].strip('"'), "Wikimedia Commons"

def nasa(q):
    p = urllib.parse.urlencode({"q": q, "media_type": "image"})
    for it in get_json(f"https://images-api.nasa.gov/search?{p}").get("collection", {}).get("items", [])[:60]:
        links = it.get("links") or []
        if links and links[0].get("href"):
            yield links[0]["href"].replace("~thumb", "~large"), it["data"][0].get("title"), "NASA", "NASA"

def photo(q):
    for url, titre, _, src in commons(f'incategory:"Featured pictures on Wikimedia Commons" {q}'):
        yield url, titre, "Photo", src

SOURCES = {"photo": photo, "aic": aic, "cma": cma, "commons": commons, "nasa": nasa}

def telecharger():
    credits = []
    connus = {f for base in (OUT, SAISONS_DIR, os.path.join(HERE, '_rejets')) for r, _, fs in os.walk(base) for f in fs}
    connus |= {f.split('-', 2)[-1] for f in connus}
    for theme, recherches in THEMES.items():
        dossier = os.path.join(SAISONS_DIR if theme in SAISONS else OUT, theme); os.makedirs(dossier, exist_ok=True)
        if len([f for f in os.listdir(dossier) if f.endswith('.jpg')]) >= 12:
            print(f"\n📁 {theme} : déjà bien rempli, on passe"); continue
        print(f"\n📁 {theme}")
        for src, q in recherches:
            gardees = 0
            try:
                for url, titre, artiste, source in SOURCES[src](q):
                    if gardees >= PAR_RECHERCHE:
                        break
                    nom = f"{clean(artiste, 30)} - {clean(titre)}.jpg"
                    final = os.path.join(dossier, nom)
                    if nom in connus:
                        continue
                    tmp = final + ".tmp"
                    try:
                        download(url, tmp)
                        w, h = dims(tmp)
                        if w == 0 or w / h < 1.15 or w < 1200:
                            os.remove(tmp); continue
                        subprocess.run(["sips", "-s", "format", "jpeg", "-s", "formatOptions", "90", "-Z", "3840", tmp, "--out", final],
                                       capture_output=True)
                        os.remove(tmp)
                        gardees += 1
                        credits.append(f"{theme} | {artiste} — {titre} ({source})")
                        print(f"   ✅ {nom}")
                    except Exception as e:
                        if os.path.exists(tmp): os.remove(tmp)
                    time.sleep(0.3)
            except Exception as e:
                print(f"   ⚠️  {q} : {e!r}")
            if gardees == 0:
                print(f"   (rien de convenable pour « {q} »)")
    with open(os.path.join(OUT, "credits.txt"), "a") as f:
        f.write("\n".join(credits) + "\n")
    print(f"\n✨ Terminé : {len(credits)} images dans le dossier « oeuvres ». Supprime celles qui ne te plaisent pas, puis : python collection.py envoyer")

def envoyer():
    from frame_art import Art
    racines = [OUT] + [os.path.join(SAISONS_DIR, t) for t in saisons_du_moment()]
    print("Saison(s) envoyée(s) :", ", ".join(saisons_du_moment()))
    fichiers = sorted(os.path.join(r, f) for base in racines for r, _, fs in os.walk(base) for f in fs if f.lower().endswith((".jpg", ".jpeg", ".png")))
    if not fichiers:
        print("Aucune image dans « oeuvres »."); return
    deja = os.path.join(HERE, "envoyees.txt")
    faites = {l.split("\t")[0] for l in open(deja).read().splitlines()} if os.path.exists(deja) else set()
    art = Art(); dernier = None
    for p in fichiers:
        rel = os.path.relpath(p, HERE)
        if rel in faites:
            continue
        try:
            img = open(p, "rb").read()
            dernier = art.upload(img, "png" if p.lower().endswith(".png") else "jpg")
            open(deja, "a").write(f"{rel}\t{dernier}\n")
            print(f"   📤 {rel}")
        except Exception as e:
            print(f"   ❌ {rel} : {e!r}")
            try: art = Art()
            except Exception: pass
        time.sleep(1)
    if dernier:
        try: art.show(dernier)
        except Exception: pass
    print("\n✅ Envoi terminé. Sur la TV : mode Art → Mes photos (tu peux y lancer le diaporama).")


def convertir():
    """Met chaque image au format exact de la Frame (3840x2160).
    Image toujours entière (recadrage seulement si moins de 2 %, invisible), sinon bandes discrètes (gris très foncé)."""
    W, H, R = 3840, 2160, 3840 / 2160
    n = 0
    for base in (OUT, SAISONS_DIR):
        for r, _, fs in os.walk(base):
            for f in fs:
                if not f.lower().endswith(".jpg"):
                    continue
                p = os.path.join(r, f)
                w, h = dims(p)
                if (w, h) == (W, H) or not h:
                    continue
                ratio = w / h
                recadrer = (ratio >= R and 1 - R / ratio <= 0.02) or (ratio < R and 1 - ratio / R <= 0.02)
                if recadrer:
                    redim = ["--resampleHeight", str(H)] if ratio >= R else ["--resampleWidth", str(W)]
                    fin = ["--cropToHeightWidth", str(H), str(W)]
                else:
                    redim = ["--resampleWidth", str(W)] if ratio >= R else ["--resampleHeight", str(H)]
                    fin = ["--padToHeightWidth", str(H), str(W), "--padColor", "1C1C1C"]
                subprocess.run(["sips"] + redim + [p], capture_output=True)
                subprocess.run(["sips"] + fin + ["-s", "formatOptions", "90", p], capture_output=True)
                n += 1
                print(f"   {'✂️ ' if recadrer else '▭ '} {f}")
    print(f"\n✅ {n} images mises au format 3840x2160 (✂️ recadrée, ▭ avec bandes)")

def reinitialiser_tv():
    """Supprime de la TV uniquement les images envoyées par toi (identifiants MY_F…).
    Les œuvres Samsung (SAM-…) ne sont jamais touchées."""
    from frame_art import Art
    def mes_images(art):
        d = art.send("get_content_list", ("get_content_list",), category="MY-C0002")
        return [c["content_id"] for c in json.loads(d.get("content_list", "[]")) if str(c.get("content_id", "")).startswith("MY_F")]
    art = Art()
    for passe in range(3):
        ids = mes_images(art)
        print(f"Passe {passe + 1} : {len(ids)} de tes images encore sur la TV")
        if not ids:
            break
        for i in range(0, len(ids), 10):
            lot = ids[i:i + 10]
            try:
                art.send("delete_image_list", ("image_deleted", "delete_image_list"), secs=15,
                         content_id_list=[{"content_id": c} for c in lot])
            except (TimeoutError, RuntimeError) as e:
                print(f"   ⚠️  lot {i // 10 + 1} : {str(e)[:120]}")
                art = Art()
            print(f"   🗑  {min(i + 10, len(ids))}/{len(ids)}")
        time.sleep(3)
        art = Art()
    restant = mes_images(art)
    if not restant:
        deja = os.path.join(HERE, "envoyees.txt")
        if os.path.exists(deja):
            os.remove(deja)
        print("✅ TV nettoyée : plus aucune de tes images, les œuvres Samsung sont intactes")
    else:
        print(f"⚠️  {len(restant)} image(s) n'ont pas pu être supprimées : {restant[:10]}")

def diaporama():
    """Active le diaporama aléatoire sur « Mes photos ».
    python collection.py diaporama 60   → change d'image toutes les 60 minutes (défaut : 60 ; « off » pour arrêter)"""
    from frame_art import Art
    val = sys.argv[2] if len(sys.argv) > 2 else "60"
    art = Art()
    ok = False
    for req in ("set_auto_rotation_status", "set_slideshow_status"):
        try:
            d = art.send(req, (req, "auto_rotation_changed", "slideshow_changed", "auto_rotation_status", "slideshow_status"),
                         secs=10, value=val, category_id="MY-C0002", type="shuffleslideshow")
            print(f"✅ {req} : {d}")
            ok = True
            break
        except (TimeoutError, RuntimeError) as e:
            print(f"   ({req} : {str(e)[:150]})")
            art = Art()
    if ok:
        print(f"🎞  Diaporama {'arrêté' if val == 'off' else f'activé : une nouvelle image toutes les {val} min, ordre aléatoire'}")
    else:
        print("❌ La TV n'a pas accepté la commande : il faudra l'activer depuis le menu du mode Art.")

def synchroniser():
    """Efface du Mac les images que tu as supprimées sur la TV avec la télécommande."""
    from frame_art import Art
    deja = os.path.join(HERE, "envoyees.txt")
    lignes = [l for l in open(deja).read().splitlines() if l.strip()]
    art = Art()
    d = art.send("get_content_list", ("get_content_list",), category="MY-C0002")
    sur_tv = {c["content_id"] for c in json.loads(d.get("content_list", "[]")) if str(c.get("content_id", "")).startswith("MY_F")}
    num = lambda c: int(c.replace("MY_F", ""))
    paires = []
    if all("\t" in l for l in lignes):
        paires = [tuple(l.split("\t", 1)) for l in lignes]
    else:
        # ancien format : on reconstitue l'ordre d'envoi et on teste où se trouve le numéro « perdu »
        envoyes = lignes
        tous = sorted(os.path.relpath(os.path.join(r, f), HERE) for base in [OUT] + [os.path.join(SAISONS_DIR, t) for t in saisons_du_moment()]
                      for r, _, fs in os.walk(base) for f in fs if f.lower().endswith((".jpg", ".jpeg", ".png")))
        rates = [x for x in tous if x not in set(envoyes)]
        bas = min(map(num, sur_tv)); haut = max(map(num, sur_tv))
        extra = haut - bas + 1 - len(envoyes)
        hypotheses = [[]] if extra <= 0 else [[r] for r in rates] if extra == 1 else []
        solutions = []
        for consommes in hypotheses:
            seq = [x for x in tous if x in set(envoyes) or x in consommes]
            ids = {x: f"MY_F{bas + i:04d}" for i, x in enumerate(seq)}
            if any(ids[x] in sur_tv for x in consommes):
                continue  # impossible : ce numéro est occupé par une vraie image
            solutions.append(tuple((x, ids[x]) for x in envoyes))
        if len(set(solutions)) != 1:
            print(f"⚠️  Correspondance incertaine ({len(set(solutions))} possibilités) : je n'efface rien par prudence. Dis-le à Claude.")
            return
        paires = list(solutions[0])
        if extra < 0:
            print("ℹ️  La première ou la dernière image a peut-être été supprimée : vérifie bien la liste avant de confirmer.")
    a_effacer = [(rel, cid) for rel, cid in paires if cid not in sur_tv]
    print(f"{len(sur_tv)} de tes images sont sur la TV, {len(a_effacer)} ont été supprimées depuis la télécommande :")
    for rel, cid in a_effacer:
        print(f"   🗑  {rel}")
    if not a_effacer:
        return
    if input("\nEffacer ces fichiers de ton Mac ? (o/n) ").strip().lower() != "o":
        print("Rien effacé."); return
    garder = []
    for rel, cid in paires:
        if cid in sur_tv:
            garder.append(f"{rel}\t{cid}")
        else:
            try: os.remove(os.path.join(HERE, rel))
            except FileNotFoundError: pass
    open(deja, "w").write("\n".join(garder) + "\n")
    print(f"✅ {len(a_effacer)} fichiers effacés, suivi mis à jour.")

if __name__ == "__main__":
    {"telecharger": telecharger, "envoyer": envoyer, "convertir": convertir, "reinitialiser-tv": reinitialiser_tv, "diaporama": diaporama, "synchroniser": synchroniser}.get(sys.argv[1] if len(sys.argv) > 1 else "", lambda: print(__doc__))()
