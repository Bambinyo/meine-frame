#!/usr/bin/env python3
"""Envoi d'une image en mode Art sur The Frame (client maison, compatible LS03F)."""
import base64, json, os, random, socket, ssl, struct, sys, time, uuid, zlib
from datetime import datetime
import websocket

HERE = os.path.dirname(os.path.abspath(__file__))
IP = "192.168.1.11"
TOKEN_FILE = os.path.join(HERE, "tv-token.txt")
def jeton():
    """Jeton d'autorisation donné par la TV (vide tant qu'on n'a pas choisi « Autoriser » sur la TV)."""
    try:
        return open(TOKEN_FILE).read().strip()
    except FileNotFoundError:
        return ""
TOKEN = jeton()
# Nom affiché par la TV dans sa demande d'autorisation (celui d'origine est gardé là où un jeton existe déjà)
def _nom_defaut():
    try:
        de = json.load(open(os.path.join(HERE, "config.json"))).get("langue") == "de"
    except Exception:
        de = False
    return "Meine FRAME" if de else "Ma Frame"
NOM_FILE = os.path.join(HERE, "tv-nom.txt")        # nom sous lequel la TV a autorisé ce Mac
def nom_appareil():
    try:
        return open(NOM_FILE).read().strip() or _nom_defaut()
    except FileNotFoundError:
        return "Claude" if TOKEN else _nom_defaut()     # première installation de Yann : « Claude »
NAME = base64.b64encode(nom_appareil().encode()).decode()
NOCERT = {"cert_reqs": ssl.CERT_NONE, "check_hostname": False}

class Art:
    def __init__(self):
        url = f"wss://{IP}:8002/api/v2/channels/com.samsung.art-app?name={NAME}&token={jeton()}"
        self.ws = websocket.create_connection(url, sslopt=NOCERT, timeout=3)
        self.wait_raw(lambda m: m.get("event") == "ms.channel.ready", 15)

    def wait_raw(self, cond, secs):
        end = time.time() + secs
        while time.time() < end:
            try:
                m = json.loads(self.ws.recv())
            except websocket.WebSocketTimeoutException:
                continue
            if cond(m):
                return m
        raise TimeoutError("pas de réponse de la TV")

    def send(self, req, expect, secs=20, **data):
        data.update({"request": req, "id": str(uuid.uuid4())})
        self.ws.send(json.dumps({"method": "ms.channel.emit", "params": {
            "event": "art_app_request", "to": "host", "data": json.dumps(data)}}))
        end = time.time() + secs
        while time.time() < end:
            m = self.wait_raw(lambda m: m.get("event") == "d2d_service_message", end - time.time())
            d = json.loads(m["data"])
            if d.get("event") in expect:
                return d
            if d.get("event") == "error":
                raise RuntimeError(f"erreur TV : {d}")
        raise TimeoutError(f"pas de réponse à {req}")

    def upload(self, img, ftype="png", matte="none"):
        cid = str(uuid.uuid4())
        d = self.send("send_image", ("ready_to_use",), file_type=ftype, request_id=cid,
                      conn_info={"d2d_mode": "socket", "connection_id": random.randrange(4 * 1024**3), "id": cid},
                      image_date=datetime.now().strftime("%Y:%m:%d %H:%M:%S"),
                      matte_id=matte, portrait_matte_id="shadowbox_polar", file_size=len(img))
        ci = json.loads(d["conn_info"])
        header = json.dumps({"num": 0, "total": 1, "fileLength": len(img), "fileName": "claude",
                             "fileType": ftype, "secKey": ci["key"], "version": "0.0.1"}).encode()
        s = socket.create_connection((ci["ip"], int(ci["port"])), timeout=20)
        if str(ci.get("secured")).lower() in ("true", "1"):
            ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
            s = ctx.wrap_socket(s)
        s.sendall(struct.pack(">I", len(header)) + header + img)
        d = self.send_wait_added(60)
        s.close()
        return d["content_id"]

    def send_wait_added(self, secs):
        end = time.time() + secs
        while time.time() < end:
            m = self.wait_raw(lambda m: m.get("event") == "d2d_service_message", end - time.time())
            d = json.loads(m["data"])
            if d.get("event") == "image_added":
                return d
            if d.get("event") == "error":
                raise RuntimeError(f"erreur TV : {d}")
        raise TimeoutError("l'image n'a pas été confirmée")

    def show(self, content_id):
        self.send("select_image", ("select_image", "image_selected"), secs=10,
                  content_id=content_id, category_id=None, show=True)

def make_png(w=1920, h=1080):
    raw = bytearray()
    for y in range(h):
        t = y / h
        raw.append(0)
        raw.extend(bytes((int(25 + 140 * t), int(55 + 90 * t), int(120 + 90 * (1 - t)))) * w)
    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(bytes(raw), 6)) + chunk(b"IEND", b""))

if __name__ == "__main__":
    if len(sys.argv) > 1:
        path = sys.argv[1]; img = open(path, "rb").read()
        ftype = "jpg" if path.lower().endswith((".jpg", ".jpeg")) else "png"
    else:
        img, ftype = make_png(), "png"
    art = Art()
    print("📤 Envoi de l'image…")
    cid = art.upload(img, ftype)
    print(f"✅ Image reçue par la TV (id {cid})")
    try:
        art.show(cid)
    except TimeoutError:
        pass  # certaines TV n'accusent pas réception de l'affichage
    print("🖼  Affichage demandé — regarde la TV")
