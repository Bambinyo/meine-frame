#!/usr/bin/env python3
"""Appli « Ma Frame » : gérer la collection et la TV depuis un navigateur.
Lancement : python app.py  (ou double-clic sur Frame.command)"""
import base64, hashlib, json, os, re, shutil, socket, ssl, subprocess, sys, threading, time, traceback
import urllib.parse, urllib.request, webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import collection as C          # dims, clean, saisons_du_moment, OUT, SAISONS_DIR, UA…
import frame_art as FA          # Art (canal mode Art)
import websocket

PORT = 8765
CONFIG = os.path.join(HERE, "config.json")
ENVOYEES = os.path.join(HERE, "envoyees.txt")
CACHE = os.path.join(HERE, ".cache", "vignettes")
TV_LOCK = threading.Lock()
TACHE = {"en_cours": False, "message": "", "fait": 0, "total": 0, "a_confirmer": []}
NOMS = {"0-photos-incroyables": "Photos incroyables", "1-chefs-doeuvre": "Chefs-d'œuvre", "2-estampes-japonaises": "Estampes japonaises",
        "3-impressionnistes": "Impressionnistes", "4-espace": "Espace", "5-printemps": "Printemps", "6-ete": "Été",
        "7-automne": "Automne", "8-hiver": "Hiver", "9-noel": "Noël", "mes-photos": "Mes photos"}
SAISONS = ["5-printemps", "6-ete", "7-automne", "8-hiver", "9-noel"]

# ---------- état local ----------
ETAT_LOCK = threading.RLock()   # une seule écriture de fichier d'état à la fois

def ecrire_atomique(chemin, texte):
    """Écrit dans un fichier temporaire puis le met en place d'un coup :
    une coupure en cours d'écriture laisse l'ancienne version intacte."""
    with ETAT_LOCK:
        tmp = f"{chemin}.{os.getpid()}.{threading.get_ident()}.tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(texte); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, chemin)

ROUTES_ETAT = {"/api/langue", "/api/masquees", "/api/collections", "/api/theme", "/api/saison", "/api/nouveau-code"}

def ecrire_json(chemin, obj, **kw):
    ecrire_atomique(chemin, json.dumps(obj, ensure_ascii=False, **kw))

def lire_json(chemin, defaut):
    try:
        return json.load(open(chemin))
    except Exception:
        return defaut

def lire_config():
    try:
        return json.load(open(CONFIG))
    except Exception:
        return {"actifs": {}, "saison_forcee": None}

def langue():
    """Langue de l'interface : « fr » (par défaut) ou « de », choisie dans Réglages ou par l'installeur."""
    return "de" if lire_config().get("langue") == "de" else "fr"

def version_appli():
    """Numéro de version (fichier VERSION, posé par le paquet) et date de la dernière mise à jour automatique."""
    try:
        v = open(os.path.join(HERE, "VERSION")).read().strip()
    except OSError:
        return None
    try:
        d = open(os.path.join(HERE, ".maj", "derniere.txt")).read().strip()
    except OSError:
        d = None
    return {"numero": v, "derniere_maj": d}

def ecrire_config(c):
    ecrire_json(CONFIG, c, indent=1)

def lire_envoyees():
    d = {}
    if os.path.exists(ENVOYEES):
        for l in open(ENVOYEES).read().splitlines():
            if "\t" in l:
                rel, cid = l.split("\t", 1); d[rel] = cid
    return d

def ecrire_envoyees(d):
    ecrire_atomique(ENVOYEES, "".join(f"{r}\t{c}\n" for r, c in d.items()))

def saisons_actives(cfg):
    if cfg.get("saison_forcee"):
        return [cfg["saison_forcee"]]
    return C.saisons_du_moment()

NOMS_PERSO = os.path.join(HERE, "noms_dossiers.json")   # noms tels que tapés (accents, majuscules)

def nom_theme(t):
    if t in NOMS:
        return NOMS[t]
    perso = lire_json(NOMS_PERSO, {}).get(t)
    if perso:
        return perso
    t = re.sub(r"^\d+-", "", t)                     # préfixe d'ordre éventuel (« 3-paysages »)
    return t.replace("-", " ").capitalize()

def themes(cfg=None):
    cfg = cfg or lire_config()
    res = []
    for base, nom_base in ((C.OUT, "oeuvres"), (C.SAISONS_DIR, "saisons")):
        if not os.path.isdir(base):
            continue
        for t in sorted(os.listdir(base)):
            d = os.path.join(base, t)
            if not os.path.isdir(d):
                continue
            if nom_base == "saisons":
                defaut = t in saisons_actives(cfg)
            else:
                defaut = True
            # un choix manuel l'emporte ; sinon, saison du moment = affichée automatiquement
            actif = cfg["actifs"].get(t, defaut)
            imgs = sorted(f for f in os.listdir(d) if f.lower().endswith((".jpg", ".jpeg", ".png")))
            res.append({"id": t, "nom": nom_theme(t), "groupe": nom_base,
                        "actif": actif, "dossier": d, "images": [os.path.relpath(os.path.join(d, f), HERE) for f in imgs]})
    return res

def chemin_sur(rel):
    p = os.path.realpath(os.path.join(HERE, rel))
    if not (p.startswith(os.path.realpath(C.OUT) + os.sep) or p.startswith(os.path.realpath(C.SAISONS_DIR) + os.sep)):
        raise ValueError("chemin refusé")
    return p

# ---------- conversion au format Frame ----------
SRGB = "/System/Library/ColorSync/Profiles/sRGB Profile.icc"

def convertir_fichier(p):
    """Met l'image au format exact de la Frame (3840×2160), en une seule compression JPEG :
    1) conversion en sRGB (couleurs fidèles sur la TV) dans un fichier TIFF sans perte,
    2) redimensionnement et bandes éventuelles sur ce TIFF,
    3) un unique enregistrement JPEG en qualité 95."""
    W, H, R = 3840, 2160, 3840 / 2160
    tif = p + ".tmp.tiff"
    etape1 = ["sips", "-s", "format", "tiff"] + (["--matchTo", SRGB] if os.path.exists(SRGB) else []) + [p, "--out", tif]
    subprocess.run(etape1, capture_output=True)
    if not os.path.exists(tif):
        subprocess.run(["sips", "-s", "format", "tiff", p, "--out", tif], capture_output=True)
    try:
        w, h = C.dims(tif)
        if h and (w, h) != (W, H):
            r = w / h
            if (r >= R and 1 - R / r <= 0.02) or (r < R and 1 - r / R <= 0.02):
                redim = ["--resampleHeight", str(H)] if r >= R else ["--resampleWidth", str(W)]
                fin = ["--cropToHeightWidth", str(H), str(W)]
            else:
                redim = ["--resampleWidth", str(W)] if r >= R else ["--resampleHeight", str(H)]
                fin = ["--padToHeightWidth", str(H), str(W), "--padColor", "1C1C1C"]
            subprocess.run(["sips"] + redim + [tif], capture_output=True)
            subprocess.run(["sips"] + fin + [tif], capture_output=True)
        subprocess.run(["sips", "-s", "format", "jpeg", "-s", "formatOptions", "95", tif, "--out", p], capture_output=True)
    finally:
        try: os.remove(tif)
        except FileNotFoundError: pass

# ---------- TV ----------
CANAL_ART = {"ok": None, "depuis": 0.0}   # le canal Art répond-il ? (la TV peut être allumée mais muette)
def noter_canal(ok):
    if CANAL_ART["ok"] != ok:
        CANAL_ART.update(ok=ok, depuis=time.time())
        print(f"[{time.strftime('%H:%M:%S')}] canal Art de la TV : {'répond' if ok else 'ne répond plus'}", flush=True)

def art():
    try:
        a = FA.Art()
    except (TimeoutError, socket.timeout, websocket.WebSocketException):
        noter_canal(False); raise
    noter_canal(True)
    return a

def message_clair(e):
    """Traduit une erreur technique en phrase compréhensible."""
    t = f"{e.__class__.__name__} {e}"
    if str(e)[:5].lower() == "la tv":
        return str(e)[0].upper() + str(e)[1:]
    if isinstance(e, ConnectionRefusedError) or "Errno 61" in t or "Connection refused" in t:
        return "La TV démarre encore ou vient de s’éteindre. Réessaie dans une minute."
    if isinstance(e, (TimeoutError, socket.timeout)) or "pas de réponse" in t or "timed out" in t.lower():
        return "La TV n’accepte des images qu’en mode Art : elles partiront toutes seules dès qu’elle y repassera."
    if isinstance(e, OSError) and any(x in t for x in ("Errno 64", "Errno 65", "No route", "Host is down", "Network is unreachable")):
        return "La TV est introuvable : est-elle allumée et sur le même Wi-Fi ?"
    return str(e)

def tv_upload(rel):
    p = chemin_sur(rel)
    img = open(p, "rb").read()
    with TV_LOCK:
        cid = art().upload(img, "jpg")
    d = lire_envoyees(); d[rel] = cid; ecrire_envoyees(d)
    return cid

def tv_supprimer(cids):
    if not cids:
        return
    with TV_LOCK:
        a = art()
        for i in range(0, len(cids), 10):
            try:
                a.send("delete_image_list", ("image_deleted", "delete_image_list"), secs=15,
                       content_id_list=[{"content_id": c} for c in cids[i:i + 10]])
            except (TimeoutError, RuntimeError):
                a = art()

def tv_mes_images():
    with TV_LOCK:
        d = art().send("get_content_list", ("get_content_list",), category="MY-C0002")
    return {c["content_id"] for c in json.loads(d.get("content_list", "[]")) if str(c.get("content_id", "")).startswith("MY_F")}

def tv_afficher(cid):
    with TV_LOCK:
        a = art()
        try:
            a.show(cid)
        except TimeoutError:
            pass
        try:
            a.send("set_artmode_status", ("artmode_status", "set_artmode_status", "go_to_standby"), secs=5, value="on")
        except Exception:
            pass

REGLAGES_ART = {  # nom TV → requête de modification
    "brightness": "set_brightness", "color_temperature": "set_color_temperature",
    "brightness_sensor_setting": "set_brightness_sensor_setting", "motion_timer": "set_motion_timer",
    "motion_sensitivity": "set_motion_sensitivity",
}

def tv_lire_reglages_art():
    with TV_LOCK:
        d = art().send("get_artmode_settings", ("get_artmode_settings",), secs=10)
    data = d.get("data")
    if isinstance(data, str):
        try: data = json.loads(data)
        except Exception: data = []
    return data if isinstance(data, list) else []

def tv_regler_art(item, valeur):
    req = REGLAGES_ART.get(item)
    if not req:
        raise ValueError("réglage inconnu")
    with TV_LOCK:
        a = art()
        try:
            a.send(req, (req, item, "artmode_settings_updated", "set_artmode_settings"), secs=6, value=str(valeur))
        except TimeoutError:
            pass  # certaines TV n'accusent pas réception

def tv_artmode(on):
    with TV_LOCK:
        a = art()
        try:
            a.send("set_artmode_status", ("artmode_status", "set_artmode_status", "go_to_standby"), secs=8, value="on" if on else "off")
        except TimeoutError:
            pass  # la TV n'accuse pas toujours réception

def tv_en_mode_art(a):
    """True / False selon ce que dit la TV, None si elle ne répond pas."""
    try:
        d = a.send("get_artmode_status", ("artmode_status", "get_artmode_status"), secs=4)
        return str(d.get("value", "")).lower() == "on"
    except (TimeoutError, RuntimeError):
        return None

def _envoyer_diaporama(a, val):
    return a.send("set_slideshow_status", ("slideshow_changed", "set_slideshow_status", "slideshow_status"), secs=10,
                  value=str(val), category_id="MY-C0002", type="shuffleslideshow")

def tv_diaporama(val):
    """Changer la fréquence relance le diaporama, ce qui fait passer la TV en mode Art.
    Pendant un programme, on garde donc le choix et on l'applique au prochain passage en mode Art."""
    cfg = lire_config(); cfg["diaporama"] = str(val); cfg["diaporama_attente"] = True; ecrire_config(cfg)
    with TV_LOCK:
        try:
            a = art()
        except Exception:
            return {"attente": True}          # TV éteinte ou canal muet : appliqué plus tard
        try:
            if tv_en_mode_art(a) is not True:
                return {"attente": True}
            _envoyer_diaporama(a, val)
        finally:
            try: a.ws.close()
            except Exception: pass
    cfg = lire_config(); cfg["diaporama_attente"] = False; ecrire_config(cfg)
    return {"attente": False}

def appliquer_diaporama_en_attente():
    cfg = lire_config()
    if not cfg.get("diaporama_attente"):
        return
    with TV_LOCK:
        a = art()
        try:
            if tv_en_mode_art(a) is not True:
                return
            _envoyer_diaporama(a, cfg.get("diaporama", "60"))
        finally:
            try: a.ws.close()
            except Exception: pass
    cfg = lire_config(); cfg["diaporama_attente"] = False; ecrire_config(cfg)
    print(f"[{time.strftime('%H:%M:%S')}] mode Art : fréquence du diaporama appliquée ({cfg.get('diaporama')})", flush=True)

class Telecommande:
    """Liaison permanente avec la TV : touches, souris virtuelle, saisie de texte.
    Se reconnecte toute seule ; suit l'ouverture/fermeture du clavier de la TV."""
    def __init__(self):
        self.ws = None; self.verrou = threading.Lock(); self.ime = False; self.champ = ""; self.vu = 0

    def _connecter(self):
        tok = FA.jeton()
        url = f"wss://{FA.IP}:8002/api/v2/channels/samsung.remote.control?name={FA.NAME}" + (f"&token={tok}" if tok else "")
        ws = websocket.create_connection(url, sslopt=FA.NOCERT, timeout=5)
        fin = time.time() + (8 if tok else 45)          # sans jeton : le temps d'appuyer sur « Autoriser » sur la TV
        while time.time() < fin:
            try:
                m = json.loads(ws.recv())
            except websocket.WebSocketTimeoutException:
                continue
            if m.get("event") == "ms.channel.connect":
                nouveau = str((m.get("data") or {}).get("token") or "")
                if nouveau and nouveau != tok:
                    ecrire_atomique(FA.TOKEN_FILE, nouveau)
                    if not os.path.exists(FA.NOM_FILE):
                        ecrire_atomique(FA.NOM_FILE, FA.nom_appareil())
                    print(f"[{time.strftime('%H:%M:%S')}] TV autorisée : jeton enregistré", flush=True)
                break
            if m.get("event") in ("ms.channel.unauthorized", "ms.channel.timeOut"):
                raise RuntimeError("TV : accès refusé")
        ws.settimeout(None)
        self.ws = ws
        threading.Thread(target=self._ecouter, args=(ws,), daemon=True).start()

    def _ecouter(self, ws):
        while self.ws is ws:
            try:
                m = json.loads(ws.recv())
            except Exception:
                if self.ws is ws: self.ws = None
                self.ime = False
                return
            ev = m.get("event")
            if ev == "ms.remote.imeStart":
                self.ime = True; self.champ = str(m.get("data") or "")
            elif ev in ("ms.remote.imeEnd", "ms.remote.imeDone"):
                self.ime = False
            self.vu = time.time()

    def envoyer(self, params):
        with self.verrou:
            for essai in (1, 2):
                try:
                    if not self.ws:
                        self._connecter()
                    self.ws.send(json.dumps({"method": "ms.remote.control", "params": params}))
                    return
                except Exception:
                    try: self.ws and self.ws.close()
                    except Exception: pass
                    self.ws = None
                    if essai == 2: raise

    def touche(self, k):
        self.envoyer({"Cmd": "Click", "DataOfCmd": k, "Option": "false", "TypeOfRemote": "SendRemoteKey"})

    def appui(self, k, duree=0.12):
        """Appui puis relâchement, comme un vrai doigt sur la télécommande : certaines applis de la TV
        (o2 TV / waipu.tv pour changer de chaîne) ignorent le « clic » instantané."""
        self.envoyer({"Cmd": "Press", "DataOfCmd": k, "Option": "false", "TypeOfRemote": "SendRemoteKey"})
        time.sleep(duree)
        self.envoyer({"Cmd": "Release", "DataOfCmd": k, "Option": "false", "TypeOfRemote": "SendRemoteKey"})

    def deplacer(self, dx, dy):
        self.envoyer({"Cmd": "Move", "Position": {"x": int(dx), "y": int(dy), "Time": str(int(time.time() * 1000))},
                      "TypeOfRemote": "ProcessMouseDevice"})

    def clic(self, n=1):
        for i in range(max(1, min(3, int(n)))):
            if i: time.sleep(0.07)
            self.envoyer({"Cmd": "LeftClick", "TypeOfRemote": "ProcessMouseDevice"})

    def texte(self, txt, valider=False):
        self.envoyer({"Cmd": base64.b64encode(txt.encode()).decode(), "DataOfCmd": "base64", "TypeOfRemote": "SendInputString"})
        if valider:
            # « fin de saisie » ferme le clavier de la TV sans valider : on appuie ensuite sur OK pour lancer
            time.sleep(0.4)
            self.envoyer({"Cmd": "", "TypeOfRemote": "SendInputEnd"})
            time.sleep(0.8)
            self.touche("KEY_ENTER")

    # défilement : dans le navigateur de la TV, la page défile quand le curseur reste au bord de l'écran
    def defiler(self, sens):
        bas = sens == "page_bas"
        maintenant = time.time()
        etat = getattr(self, "_defil", None)
        if etat is None or etat["bas"] != bas:
            self.deplacer(0, 5000 if bas else -5000)          # filer au bord concerné
            self._defil = etat = {"bas": bas, "dernier": maintenant}
            threading.Thread(target=self._fin_defil, args=(etat,), daemon=True).start()
        etat["dernier"] = maintenant

    def _fin_defil(self, etat):
        while time.time() - etat["dernier"] < 0.45:           # tant que le geste continue
            time.sleep(0.05)
        if getattr(self, "_defil", None) is etat:
            self._defil = None
            try: self.deplacer(0, -260 if etat["bas"] else 260)   # quitter le bord → la page s'arrête
            except Exception: pass

    def preparer(self):
        """Ouvre la liaison à l'avance, pour que la TV associe son clavier à Ma Frame."""
        try:
            with self.verrou:
                if not self.ws: self._connecter()
        except Exception:
            pass

TC = Telecommande()

def tv_touche(k):
    TC.touche(k)

def assurer_mode_art():
    """Le canal Art de la TV ne répond pas quand elle est sur l'accueil ou une chaîne.
    À la demande de l'utilisateur seulement (jamais en tâche de fond) : si le canal se tait alors que la TV est allumée,
    on fait un appui court sur Marche (sur une Frame, il bascule en mode Art), puis on réessaie une fois."""
    try:
        art().ws.close(); return
    except Exception as e:
        if not tv_joignable():
            raise TimeoutError("la TV est éteinte ou injoignable")
        print(f"[{time.strftime('%H:%M:%S')}] canal Art muet ({e.__class__.__name__}) : passage en mode Art", flush=True)
    TC.touche("KEY_POWER")
    time.sleep(4)
    try:
        art().ws.close()
    except Exception:
        raise TimeoutError("la TV ne répond pas : mets-la en mode Art avec sa télécommande, puis réessaie")

RECHERCHE_TV = {"en_cours": False, "derniere": 0}

def infos_tv(ip, delai=1.0):
    try:
        with urllib.request.urlopen(f"http://{ip}:8001/api/v2/", timeout=delai) as r:
            return json.load(r).get("device", {})
    except Exception:
        return None

def chercher_tv():
    """Parcourt le réseau local à la recherche de la Frame (même identifiant que la dernière fois si connu)."""
    if RECHERCHE_TV["en_cours"] or time.time() - RECHERCHE_TV["derniere"] < 60:
        return
    RECHERCHE_TV.update(en_cours=True, derniere=time.time())
    try:
        from concurrent.futures import ThreadPoolExecutor
        cfg = lire_config(); ident = cfg.get("tv_id")
        base = ip_locale().rsplit(".", 1)[0]
        ips = [f"{base}.{i}" for i in range(1, 255)]
        with ThreadPoolExecutor(64) as ex:
            for ip, dev in zip(ips, ex.map(lambda x: infos_tv(x, 0.6), ips)):
                if dev and str(dev.get("FrameTVSupport")).lower() == "true" and (not ident or dev.get("id") == ident):
                    if ip != FA.IP:
                        print(f"[{time.strftime('%H:%M:%S')}] TV retrouvée : {FA.IP} → {ip}", flush=True)
                    FA.IP = ip
                    cfg = lire_config(); cfg["tv_ip"] = ip; cfg["tv_id"] = dev.get("id"); ecrire_config(cfg)
                    break
    finally:
        RECHERCHE_TV["en_cours"] = False

def tv_joignable():
    try:
        s = socket.create_connection((FA.IP, 8001), timeout=1.5); s.close()
        cfg = lire_config()
        if not cfg.get("tv_id"):  # mémoriser l'identité de la TV la première fois
            dev = infos_tv(FA.IP)
            if dev: cfg["tv_id"] = dev.get("id"); cfg["tv_ip"] = FA.IP; ecrire_config(cfg)
        return True
    except Exception as e:
        print(f"[{time.strftime('%H:%M:%S')}] TV injoignable à {FA.IP} ({e.__class__.__name__}) : recherche sur le réseau…", flush=True)
        threading.Thread(target=chercher_tv, daemon=True).start()
        return False

def importer_suppressions(manuel=False):
    """Efface du Mac les images supprimées depuis la télécommande. Renvoie le nombre d'images effacées."""
    env = lire_envoyees()
    if not env:
        return 0
    sur_tv = tv_mes_images()
    if not sur_tv:
        return 0  # liste vide = réponse douteuse de la TV : on ne touche à rien
    disparues = [r for r, c in env.items() if c not in sur_tv]
    if not manuel and len(disparues) > max(30, len(env) // 2):
        print(f"[{time.strftime('%H:%M:%S')}] {len(disparues)} images absentes de la TV : trop pour être une suppression, on ne touche à rien", flush=True)
        return 0
    for r in disparues:
        env.pop(r, None)
        try:
            os.remove(chemin_sur(r))
        except (FileNotFoundError, ValueError):
            pass
    if disparues:
        ecrire_envoyees(env)
        print(f"[{time.strftime('%H:%M:%S')}] {len(disparues)} image(s) supprimée(s) sur la TV → effacée(s) du Mac", flush=True)
    return len(disparues)

def nettoyer(max_cache=300 * 1024**2, cible=200 * 1024**2, max_journal=1024**2):
    """Plafonne le cache des aperçus et le journal."""
    try:
        if os.path.isdir(PROXY):
            fichiers = [os.path.join(PROXY, f) for f in os.listdir(PROXY)]
            infos = sorted(((os.path.getmtime(f), os.path.getsize(f), f) for f in fichiers if os.path.isfile(f)))
            total = sum(t for _, t, _ in infos)
            if total > max_cache:
                for _, t, f in infos:
                    os.remove(f); total -= t
                    if total <= cible: break
                print(f"[{time.strftime('%H:%M:%S')}] cache des aperçus réduit à {total // 1024**2} Mo", flush=True)
        j = os.path.join(HERE, ".cache", "app.log")
        if os.path.exists(j) and os.path.getsize(j) > max_journal:
            fin = open(j, "rb").read()[-200_000:]
            open(j, "wb").write(b"[journal raccourci]\n" + fin)
    except Exception as e:
        print(f"nettoyage : {e!r}", flush=True)

def surveillance():
    nettoyer(); n = 0
    while True:
        time.sleep(120); n += 1
        if n % 30 == 0:
            nettoyer()
        if TACHE["en_cours"] or not tv_joignable():
            continue
        try:
            importer_suppressions()
            reprendre_envois()
            appliquer_diaporama_en_attente()
        except Exception as e:
            print(f"surveillance : {e!r}", flush=True)

JUMELAGE = {"en_cours": False}
def premier_lancement():
    """Nouvelle installation : trouver la TV, obtenir son autorisation, puis remplir une petite collection."""
    while not FA.jeton():
        if tv_joignable() and not JUMELAGE["en_cours"]:
            JUMELAGE["en_cours"] = True
            print(f"[{time.strftime('%H:%M:%S')}] demande d'autorisation envoyée à la TV ({FA.IP})", flush=True)
            try:
                TC._connecter()
            except Exception as e:
                print(f"[{time.strftime('%H:%M:%S')}] autorisation non obtenue : {e!r}", flush=True)
            finally:
                JUMELAGE["en_cours"] = False
        time.sleep(15)
    if not lire_config().get("depart_fait") and not any(t["images"] for t in themes()):
        collection_de_depart()

# Collection de départ : quelques images libres de droits choisies par recherche (thème, requête, nombre)
DEPART = [("0-photos-incroyables", "photos:landscape|photos:mountains|photos:national park", 8),
          ("1-chefs-doeuvre", "cma:Claude Monet|cma:Vincent van Gogh|aic:Caspar David Friedrich|cma:J. M. W. Turner", 8),
          ("2-estampes-japonaises", "cma:Hokusai|cma:Hiroshige", 6),
          ("3-impressionnistes", "cma:Camille Pissarro|cma:Alfred Sisley|aic:Gustave Caillebotte", 6),
          ("4-espace", "nasa:nebula|nasa:galaxy", 6),
          ("5-printemps", "cma:spring landscape|photos:cherry blossom", 4), ("6-ete", "cma:summer landscape|photos:beach", 4),
          ("7-automne", "cma:autumn landscape|photos:autumn", 4), ("8-hiver", "cma:winter landscape snow|photos:snow", 4),
          ("9-noel", "cma:nativity|photos:christmas market", 3)]
def collection_de_depart():
    T = TACHE
    if T["en_cours"]:
        return
    total = sum(n for _, _, n in DEPART)
    T.update(en_cours=True, message="Collection de départ", fait=0, total=total, a_confirmer=[])
    try:
        for theme, requete, n in DEPART:
            try:
                res, _ = recherche_multi(requete)
            except Exception as e:
                print(f"départ : recherche {requete!r} : {e!r}", flush=True); res = []
            bons = sorted(res, key=lambda r: (not r.get("paysage"), -(r.get("largeur") or 0)))
            pris = 0
            for r in bons:
                if pris >= n:
                    break
                if r.get("largeur") and r["largeur"] < 2400:
                    continue
                try:
                    rel, _ = ajouter(r["url"], r.get("titre") or "sans titre", r.get("artiste") or "", theme)
                    noter_tags(os.path.basename(rel), r.get("tags") or [])
                    pris += 1; T["fait"] += 1
                except Exception as e:
                    print(f"départ : {r.get('titre')!r} : {e!r}", flush=True)
            T["fait"] += n - pris
        cfg = lire_config(); cfg["depart_fait"] = True; ecrire_config(cfg)
    finally:
        T["en_cours"] = False
    preparer_vignettes()
    synchroniser()

REPRISE = {"cles": None, "instant": 0.0}
def reprendre_envois():
    """La TV répond : si des images attendent, on les envoie sans attendre le bouton Synchroniser.
    Même liste en attente qu'au dernier essai : on ne réessaie qu'au bout de 30 minutes (évite de boucler sur une image qui échoue)."""
    if TACHE["en_cours"]:
        return
    env = lire_envoyees()
    attente = frozenset(r for t in themes() if t["actif"] for r in t["images"] if r not in env)
    if not attente:
        return
    if attente == REPRISE["cles"] and time.time() - REPRISE["instant"] < 1800:
        return
    REPRISE.update(cles=attente, instant=time.time())
    print(f"[{time.strftime('%H:%M:%S')}] la TV répond : envoi de {len(attente)} image(s) en attente", flush=True)
    threading.Thread(target=synchroniser, daemon=True).start()

# ---------- synchronisation (tâche de fond) ----------
def synchroniser():
    T = TACHE
    T.update(en_cours=True, message="Lecture de la TV…", fait=0, total=0, a_confirmer=[])
    try:
        n = importer_suppressions(manuel=True)
        env = lire_envoyees()
        T["a_confirmer"] = []
        # 2) ce qui doit être sur la TV
        voulues = {r for t in themes() if t["actif"] for r in t["images"]}
        a_retirer = [env[r] for r in env if r not in voulues]
        T["message"] = f"Retrait de {len(a_retirer)} image(s) des thèmes désactivés…"
        tv_supprimer(a_retirer)
        for r in [r for r in env if r not in voulues]:
            env.pop(r)
        ecrire_envoyees(env)
        a_envoyer = sorted(voulues - set(env))
        T.update(total=len(a_envoyer), fait=0)
        for r in a_envoyer:
            T["message"] = f"Envoi : {os.path.basename(r)}"
            try:
                tv_upload(r)
            except Exception as e:
                T["message"] = f"Échec pour {os.path.basename(r)} : {message_clair(e)}"
            T["fait"] += 1
        T["message"] = "Synchronisation terminée" + (f" — {n} image(s) supprimée(s) depuis la télécommande effacée(s) du Mac" if n else "")
    except Exception as e:
        T["message"] = message_clair(e)
        traceback.print_exc()
    finally:
        T["en_cours"] = False

# ---------- recherche de nouvelles images ----------
DELAI_RECHERCHE = 8   # secondes : une source lente ne retient pas les autres
def get_json(url, delai=DELAI_RECHERCHE):
    with urllib.request.urlopen(urllib.request.Request(url, headers=C.UA), timeout=delai) as r:
        return json.load(r)

TRAD_TAGS = {"landscape": "Paysage", "landscapes": "Paysages", "landscape paintings": "Paysages", "portrait": "Portrait", "portraits": "Portraits",
  "still life": "Nature morte", "snow": "Neige", "winter": "Hiver", "summer": "Été", "spring": "Printemps", "autumn": "Automne", "fall": "Automne",
  "sea": "Mer", "seascape": "Marine", "marine": "Marine", "seascapes": "Marines", "ocean": "Océan", "beach": "Plage", "river": "Rivière", "rivers": "Rivières",
  "mountain": "Montagne", "mountains": "Montagnes", "flowers": "Fleurs", "flower": "Fleur", "trees": "Arbres", "tree": "Arbre", "forest": "Forêt",
  "city": "Ville", "cities": "Villes", "cityscape": "Ville", "architecture": "Architecture", "bridge": "Pont", "bridges": "Ponts", "boats": "Bateaux",
  "ships": "Bateaux", "harbor": "Port", "harbors": "Ports", "night": "Nuit", "sky": "Ciel", "clouds": "Nuages", "animals": "Animaux", "birds": "Oiseaux",
  "horses": "Chevaux", "cats": "Chats", "women": "Femmes", "children": "Enfants", "religion": "Religion", "christianity": "Religion",
  "impressionism": "Impressionnisme", "post-impressionism": "Post-impressionnisme", "realism": "Réalisme", "romanticism": "Romantisme",
  "japanese": "Japon", "japan": "Japon", "edo period": "Époque d'Edo", "ukiyo-e": "Ukiyo-e", "chinese": "Chine", "china": "Chine",
  "french": "France", "france": "France", "dutch": "Pays-Bas", "netherlands": "Pays-Bas", "american": "États-Unis", "united states": "États-Unis",
  "england": "Angleterre", "english": "Angleterre", "italy": "Italie", "italian": "Italie", "germany": "Allemagne", "german": "Allemagne", "danish": "Danemark", "denmark": "Danemark",
  "painting": "Peinture", "paintings": "Peinture", "print": "Estampe", "prints": "Estampes", "drawing": "Dessin", "drawings": "Dessins",
  "photograph": "Photographie", "photography": "Photographie", "woodblock print": "Gravure sur bois", "oil on canvas": "Huile sur toile",
  "watercolor": "Aquarelle", "galaxy": "Galaxie", "galaxies": "Galaxies", "nebula": "Nébuleuse", "nebulae": "Nébuleuses", "stars": "Étoiles",
  "milky way": "Voie lactée", "aurora": "Aurore", "earth": "Terre", "hubble": "Hubble", "james webb space telescope": "James Webb",
  "painting and sculpture of europe": "Peinture européenne", "arts of asia": "Art asiatique", "prints and drawings": "Estampes et dessins",
  "photography and media": "Photographie", "european painting and sculpture": "Peinture européenne", "japanese art": "Art japonais",
  "american painting and sculpture": "Peinture américaine", "chinese art": "Art chinois"}

def siecle(date):
    m = re.search(r"(1[0-9])\d\d", str(date or ""))
    if not m: return None
    n = int(m.group(1)) + 1
    romains = {11:"XIe",12:"XIIe",13:"XIIIe",14:"XIVe",15:"XVe",16:"XVIe",17:"XVIIe",18:"XVIIIe",19:"XIXe",20:"XXe"}
    return f"{romains.get(n, str(n) + 'e')} siècle"

def tags_propres(liste):
    vus, out = set(), []
    for t in liste:
        t = re.sub(r"\s+", " ", str(t or "")).strip(" ,;")
        if not t or len(t) > 40: continue
        t = TRAD_TAGS.get(t.lower(), t[:1].upper() + t[1:])
        if t.lower() not in vus:
            vus.add(t.lower()); out.append(t)
    return out[:8]

def rech_aic(q, page=1):
    p = urllib.parse.urlencode({"q": q, "query[term][is_public_domain]": "true", "limit": 40, "page": page,
                                "fields": "id,title,artist_title,image_id,thumbnail,style_title,classification_title,date_display,place_of_origin,subject_titles,term_titles"})
    d = get_json(f"https://api.artic.edu/api/v1/artworks/search?{p}")
    base = d.get("config", {}).get("iiif_url", "https://www.artic.edu/iiif/2")
    out = []
    for a in d.get("data", []):
        if a.get("image_id"):
            t = a.get("thumbnail") or {}
            out.append({"tags": tags_propres([a.get("style_title"), a.get("classification_title"), siecle(a.get("date_display")), a.get("place_of_origin")]
                                             + (a.get("subject_titles") or [])[:6] + (a.get("term_titles") or [])[:4]),
                        "largeur": min(1686, t.get("width") or 1686),
                        "vignette": f"{base}/{a['image_id']}/full/400,/0/default.jpg",
                        "url": f"{base}/{a['image_id']}/full/1686,/0/default.jpg", "apercu": f"{base}/{a['image_id']}/full/843,/0/default.jpg", "titre": a.get("title"),
                        "artiste": a.get("artist_title") or "", "source": "Art Institute of Chicago",
                        "paysage": bool(t.get("height")) and t.get("width", 0) / t["height"] >= 1.15})
    return out

def rech_cma(q, page=1):
    p = urllib.parse.urlencode({"q": q, "has_image": 1, "cc0": 1, "limit": 40, "skip": (page - 1) * 40})
    out = []
    for a in get_json(f"https://openaccess-api.clevelandart.org/api/artworks/?{p}").get("data", []):
        im = a.get("images") or {}
        web, gros = im.get("web") or {}, im.get("print") or im.get("web") or {}
        if web.get("url"):
            w, h = int(gros.get("width") or 0), int(gros.get("height") or 0)
            out.append({"tags": tags_propres([a.get("type"), a.get("technique"), siecle(a.get("creation_date")), (a.get("culture") or [None])[0], a.get("department")]),
                        "largeur": w or None, "vignette": web["url"], "url": gros.get("url") or web["url"], "apercu": web["url"], "titre": a.get("title"),
                        "artiste": (a.get("creators") or [{}])[0].get("description", "").split(" (")[0],
                        "source": "Cleveland Museum of Art", "paysage": bool(h) and w / h >= 1.15})
    return out

def rech_nasa(q, page=1):
    p = urllib.parse.urlencode({"q": q, "media_type": "image", "page": page, "page_size": 40})
    out = []
    for it in get_json(f"https://images-api.nasa.gov/search?{p}").get("collection", {}).get("items", [])[:40]:
        l = (it.get("links") or [{}])[0].get("href")
        if l:
            out.append({"tags": tags_propres(["Espace"] + (it["data"][0].get("keywords") or [])[:6]),
                        "largeur": None, "vignette": l, "url": l.replace("~thumb", "~orig"), "apercu": l.replace("~thumb", "~medium"), "titre": it["data"][0].get("title"),
                        "artiste": "NASA", "source": "NASA", "paysage": True})
    return out

def rech_commons(q, remarquables, page=1, expr=None):
    # « remarquables » : photos labellisées de qualité ; sinon : uniquement des reproductions d'œuvres d'art
    # (fichiers portant la mention « reproduction numérique de » = propriété P6243 dans Wikimedia)
    s = expr or (f'incategory:"Featured pictures on Wikimedia Commons" {q}' if remarquables else f"haswbstatement:P6243 {q}")
    def chercher(expr):
        p = urllib.parse.urlencode({"action": "query", "format": "json", "generator": "search", "gsrsearch": f"{expr} filetype:bitmap",
                                    "gsrnamespace": 6, "gsrlimit": 40, "gsroffset": (page - 1) * 40, "prop": "imageinfo|categories", "iiprop": "url|size", "iiurlwidth": 500,
                                    "clshow": "!hidden", "cllimit": "max"})
        return (get_json(f"https://commons.wikimedia.org/w/api.php?{p}").get("query") or {}).get("pages", {})
    pages = chercher(s)
    if not pages and not remarquables and not expr and page == 1:
        # repli : tableaux et estampes seulement
        pages = chercher(f'{q} incategory:"Paintings" OR {q} "painting" -flag -map -logo')
    out = []
    for pg in sorted(pages.values(), key=lambda x: x.get("index", 99)):
        ii = (pg.get("imageinfo") or [{}])[0]
        if not ii.get("thumburl"):
            continue
        w, h = ii.get("width", 0), ii.get("height", 0)
        grand = ii["thumburl"].replace("/500px-", "/3840px-") if w > 3840 else ii["url"]
        titre = pg.get("title", "").replace("File:", "").rsplit(".", 1)[0]
        moyen = ii["thumburl"].replace("/500px-", "/1280px-") if w > 1280 else ii["url"]
        cats = [c.get("title", "").replace("Category:", "") for c in (pg.get("categories") or [])]
        out.append({"tags": tags_propres((["Photographie"] if remarquables else []) + [re.sub(r"^(Featured pictures of|Quality images of|Paintings by|Prints by|Photographs of) ", "", c) for c in cats
                                   if not re.search(r"Wikimedia|Featured pictures on|Quality images|Valued|CC-|Pictures of the|Media |Files |Images |uploaded|Google Art Project|PD-|\d{4}-\d{2}", c)][:6]),
                    "largeur": min(w, 3840) if w else None, "vignette": ii["thumburl"], "url": grand, "apercu": moyen, "titre": titre, "artiste": "Photo" if remarquables else "",
                    "source": "Wikimedia Commons", "paysage": bool(h) and w / h >= 1.15})
    return out

def iiif_taille(base, w, maxi=3840):
    """Adresse IIIF : taille d'origine, ou 3840 px de large au plus."""
    return f"{base}/full/{maxi},/0/default.jpg" if w and w > maxi else f"{base}/full/full/0/default.jpg"

def rech_smk(q, page=1):
    """Statens Museum for Kunst (Copenhague) : domaine public, souvent 4K."""
    p = urllib.parse.urlencode({"keys": q, "offset": (page - 1) * 40, "rows": 40, "lang": "en",
                                "filters": "[has_image:true],[public_domain:true]"})
    out = []
    for a in get_json(f"https://api.smk.dk/api/v1/art/search/?{p}").get("items", []):
        base, w, h = a.get("image_iiif_id"), int(a.get("image_width") or 0), int(a.get("image_height") or 0)
        vign = a.get("image_thumbnail")
        if not (base or a.get("image_native")) or not vign:
            continue
        titres = a.get("titles") or [{}]
        titre = next((t.get("title") for t in titres if t.get("language") == "engelsk"), titres[0].get("title"))
        prod = (a.get("production") or [{}])[0]
        artiste = (a.get("artist") or [None])[0] or (prod.get("creator") or "")
        out.append({"tags": tags_propres([(a.get("object_names") or [{}])[0].get("name"), (a.get("techniques") or [None])[0],
                                          siecle((a.get("production_date") or [{}])[0].get("period")), prod.get("creator_nationality")]),
                    "largeur": min(w, 3840) if w else None, "vignette": vign.replace("/!1024,/", "/!400,/"),
                    "url": iiif_taille(base, w) if base else a["image_native"], "apercu": vign, "titre": titre,
                    "artiste": artiste, "source": "Statens Museum for Kunst", "paysage": bool(h) and w / h >= 1.15})
    return out

def rech_mia(q, page=1):
    """Minneapolis Institute of Art : œuvres du domaine public, souvent 4K+."""
    expr = urllib.parse.quote(f'{q} rights_type:"Public Domain" image:valid public_access:1')
    d = get_json(f"https://search.artsmia.org/{expr}?size={min(40 * page, 200)}")
    out = []
    for hit in ((d.get("hits") or {}).get("hits") or [])[(page - 1) * 40:]:
        a, i = hit.get("_source") or {}, hit.get("_id")
        if not i or a.get("rights_type") != "Public Domain":
            continue
        w, h = int(a.get("image_width") or 0), int(a.get("image_height") or 0)
        img = f"https://1.api.artsmia.org/{{}}/{i}.jpg"   # tailles : 800 (aperçu) ou full (original)
        out.append({"tags": tags_propres([a.get("classification"), siecle(a.get("dated")), a.get("nationality"), a.get("department")]),
                    "largeur": min(w, 3840) if w else None, "vignette": img.format(800),
                    "url": img.format("full"), "apercu": img.format(800), "titre": a.get("title"),
                    "artiste": (a.get("artist") or "").replace("Artist: ", "").split(";")[0].strip(),
                    "source": "Minneapolis Institute of Art", "paysage": bool(h) and w / h >= 1.15})
    return out

# Grands musées d'Europe dont les reproductions sont sur Wikimedia Commons (propriété « collection », P195)
GRANDS_MUSEES = {"Q19675": "Louvre", "Q23402": "Musée d'Orsay", "Q51252": "Galerie des Offices", "Q180788": "National Gallery",
                 "Q430682": "Tate", "Q160112": "Prado", "Q190804": "Rijksmuseum",
                 "Q154568": "Alte Pinakothek", "Q165631": "Gemäldegalerie de Berlin", "Q163804": "Städel", "Q162111": "Alte Nationalgalerie",
                 "Q147662": "Pinacoteca di Brera", "Q640447": "Galerie Borghèse"}
def rech_europe(q, page=1):
    """Tableaux des grands musées d'Europe : Wikidata (collection + image) → fichiers de Wikimedia Commons."""
    wd = "https://www.wikidata.org/w/api.php?"
    filtre = "haswbstatement:" + "|".join(f"P195={k}" for k in GRANDS_MUSEES)
    p = urllib.parse.urlencode({"action": "query", "format": "json", "list": "search", "srnamespace": 0, "srlimit": 40,
                                "sroffset": (page - 1) * 40, "srsearch": f"{filtre} haswbstatement:P18 {q}"})
    ids = [r["title"] for r in (get_json(wd + p).get("query") or {}).get("search", [])]
    if not ids:
        return []
    p = urllib.parse.urlencode({"action": "wbgetentities", "format": "json", "ids": "|".join(ids), "props": "labels|descriptions|claims", "languages": "fr|en"})
    ent = get_json(wd + p).get("entities") or {}
    oeuvres = []
    for i in ids:
        e = ent.get(i) or {}; cl = e.get("claims") or {}
        def val(prop):
            return [((c.get("mainsnak") or {}).get("datavalue") or {}).get("value") for c in cl.get(prop, [])]
        fichier = next((v for v in val("P18") if isinstance(v, str)), None)
        musee = next((GRANDS_MUSEES[v["id"]] for v in val("P195") if isinstance(v, dict) and v.get("id") in GRANDS_MUSEES), None)
        if not fichier or not musee:
            continue
        lab, desc = e.get("labels") or {}, e.get("descriptions") or {}
        titre = (lab.get("fr") or lab.get("en") or {}).get("value") or fichier.rsplit(".", 1)[0]
        d = (desc.get("en") or {}).get("value") or ""
        m = re.search(r"\bby ([^,(]+)", d) or re.search(r"\bde ([A-ZÀ-Ý][^,(]+)", (desc.get("fr") or {}).get("value") or "")
        oeuvres.append((fichier, titre, m.group(1).strip() if m else "", musee, siecle(d)))
    p = urllib.parse.urlencode({"action": "query", "format": "json", "prop": "imageinfo", "iiprop": "url|size", "iiurlwidth": 500,
                                "titles": "|".join("File:" + f for f, *_ in oeuvres)})
    pages = (get_json(f"https://commons.wikimedia.org/w/api.php?{p}").get("query") or {}).get("pages", {})
    infos = {pg.get("title", "").replace("File:", "").replace("_", " "): (pg.get("imageinfo") or [{}])[0] for pg in pages.values()}
    out = []
    for fichier, titre, artiste, musee, sc in oeuvres:
        ii = infos.get(fichier.replace("_", " ")) or {}
        if not ii.get("thumburl"):
            continue
        w, h = ii.get("width", 0), ii.get("height", 0)
        out.append({"tags": tags_propres(["Peinture", musee, sc]), "largeur": min(w, 3840) if w else None, "vignette": ii["thumburl"],
                    "url": ii["thumburl"].replace("/500px-", "/3840px-") if w > 3840 else ii["url"],
                    "apercu": ii["thumburl"].replace("/500px-", "/1280px-") if w > 1280 else ii["url"],
                    "titre": titre, "artiste": artiste, "source": f"{musee} · Wikimedia", "paysage": bool(h) and w / h >= 1.15})
    return out

def rech_vam(q, page=1):
    """Victoria and Albert Museum (Londres) : images jusqu'à 2 500 px, usage personnel autorisé."""
    p = urllib.parse.urlencode({"q": q, "images_exist": 1, "page_size": 40, "page": page})
    out = []
    for a in get_json(f"https://api.vam.ac.uk/v2/objects/search?{p}").get("records", []):
        base = ((a.get("_images") or {}).get("_iiif_image_base_url") or "").rstrip("/")
        if not base:
            continue
        out.append({"tags": tags_propres([a.get("objectType"), siecle(a.get("_primaryDate")), a.get("_primaryPlace")]),
                    "largeur": 2500, "vignette": f"{base}/full/400,/0/default.jpg", "url": f"{base}/full/full/0/default.jpg",
                    "apercu": f"{base}/full/1250,/0/default.jpg", "titre": a.get("_primaryTitle") or a.get("objectType"),
                    "artiste": ((a.get("_primaryMaker") or {}).get("name") or "").replace("Unknown", "").strip(),
                    "source": "Victoria and Albert Museum", "paysage": True})
    return out

def melanger(listes):
    """Résultats entrelacés source par source, sans doublon (même titre et même artiste)."""
    out, vus = [], set()
    for i in range(max(map(len, listes), default=0)):
        for l in listes:
            if i < len(l):
                cle = sans_accent(f"{l[i].get('titre')}|{l[i].get('artiste')}")
                if cle not in vus:
                    vus.add(cle); out.append(l[i])
    return out

def en_parallele(fonctions, q, page=1):
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(len(fonctions)) as ex:
        return list(ex.map(lambda f: rech_sure(f)(q, page), fonctions))

# Copenhague (rech_smk) mis de côté le 7 nov. 2026 : sa recherche répond, mais ses serveurs d'images (iip.smk.dk) ne répondent pas depuis le réseau de Yann.
MUSEES = [rech_aic, rech_cma, rech_europe, rech_mia, rech_vam]
def rech_musees(q, page=1):
    return melanger(en_parallele(MUSEES, q, page))

def rech_tout(q, page=1):
    return melanger(en_parallele(MUSEES + [lambda x, p: rech_commons(x, True, p), lambda x, p: rech_commons(x, False, p), rech_nasa], q, page))

def rech_sure(f):
    def g(q, page=1):
        try:
            return f(q, page)
        except Exception as e:
            print(f"[{time.strftime('%H:%M:%S')}] recherche « {q} » : {e!r}", flush=True)
            return []
    return g

RECHERCHES = {"tout": rech_tout, "musees": rech_musees, "aic": rech_aic, "cma": rech_cma, "smk": rech_smk, "mia": rech_mia, "vam": rech_vam, "europe": rech_europe, "nasa": rech_nasa,
              "photos": lambda q, p=1: rech_commons(q, True, p), "commons": lambda q, p=1: rech_commons(q, False, p)}

RETRAIT = {"en_cours": False, "fait": 0, "total": 0}
def retraiter_ajoutees():
    """Retélécharge depuis leur source les images ajoutées via l'appli et les retraite en meilleure qualité,
    puis remplace leur version sur la TV."""
    RETRAIT.update(en_cours=True, fait=0)
    try:
        src = lire_sources(); env = lire_envoyees()
        items = [(u, r) for u, r in src.items() if os.path.exists(os.path.join(HERE, r))]
        RETRAIT["total"] = len(items)
        for url, rel in items:
            try:
                retraiter_un(rel, url)
            except Exception as e:
                print(f"retraitement {rel} : {e!r}", flush=True)
            RETRAIT["fait"] += 1
    finally:
        RETRAIT["en_cours"] = False

def retraiter_un(rel, url):
    """Retélécharge une image depuis sa source, la retraite et la remplace sur la TV si elle y est."""
    p = os.path.join(HERE, rel); env = lire_envoyees()
    essais = [url] + ([url.replace("~orig", "~large")] if "~orig" in url else [])
    if "/thumb/" in url and "px-" in url:
        essais.append(re.sub(r"/\d+px-", "/1920px-", url))
    for v in essais:
        try:
            telecharger_poli(v, p + ".dl")
            if "~orig" in v and os.path.getsize(p + ".dl") > 40 * 1024**2:
                continue
            break
        except urllib.error.HTTPError:
            continue
    else:
        raise ValueError("source indisponible")
    os.replace(p + ".dl", p)
    convertir_fichier(p)
    if rel in env:
        tv_supprimer([env.pop(rel)]); ecrire_envoyees(env)
        tv_upload(rel)
    preparer_vignettes([rel])

def source_des_credits():
    """credits.txt (premiers téléchargements) : nom de fichier → nom de la source."""
    m = {}
    for base in (C.OUT, C.SAISONS_DIR):
        f = os.path.join(base, "credits.txt")
        if not os.path.exists(f):
            continue
        for l in open(f, encoding="utf-8", errors="ignore").read().splitlines():
            if " | " not in l or " — " not in l:
                continue
            corps = l.split(" | ", 1)[1]
            artiste, reste = corps.split(" — ", 1)
            mm = re.match(r"(.*) \(([^()]*)\)$", reste)
            if mm:
                titre, src = mm.group(1), mm.group(2)
                m[nom_fichier(titre, "" if artiste == "None" else artiste)] = src
    return m

RETRAIT_TOUT = {"en_cours": False, "fait": 0, "total": 0, "trouvees": 0, "introuvables": 0}
def retraiter_tout():
    """Retrouve à leur source les images de la collection (correspondance exacte artiste + titre),
    puis les retraite en meilleure qualité et les remplace sur la TV."""
    T = RETRAIT_TOUT; T.update(en_cours=True, fait=0, trouvees=0, introuvables=0)
    try:
        src_conn = lire_sources(); deja = set(src_conn.values()) | set(lire_importees().values())
        credits = source_des_credits()
        rels = [r for t in themes() for r in t["images"] if r not in deja]
        T["total"] = len(rels)
        ordre_src = {"Art Institute of Chicago": ["aic"], "Cleveland Museum of Art": ["cma"], "NASA": ["nasa"],
                     "Wikimedia Commons": ["photos", "commons"], "The Met": ["aic", "cma", "commons"],
                     "Statens Museum for Kunst": ["smk"], "Minneapolis Institute of Art": ["mia"], "Victoria and Albert Museum": ["vam"]}
        ordre_src.update({f"{m} · Wikimedia": ["europe", "commons"] for m in GRANDS_MUSEES.values()})
        for rel in rels:
            nom = os.path.basename(rel)
            artiste, _, titre = nom[:-4].partition(" - ")
            if not titre:
                titre, artiste = artiste, ""
            if artiste == "Photo": sources = ["photos", "commons"]
            elif artiste == "NASA": sources = ["nasa"]
            else: sources = ordre_src.get(credits.get(nom, ""), ["aic", "cma", "commons"])
            trouve = None
            for so in sources:
                for q in (f"{titre} {artiste}" if artiste not in ("Photo", "NASA", "sans titre") else titre, titre):
                    try:
                        res = RECHERCHES[so](q, 1)
                    except Exception as e:
                        print(f"recherche {nom} ({so}) : {e!r}", flush=True); res = []
                    trouve = next((r for r in res if nom_fichier(r.get("titre") or "sans titre", r.get("artiste") or "") == nom), None)
                    time.sleep(0.4)   # ménager les serveurs des musées
                    if trouve: break
                if trouve: break
            if trouve:
                try:
                    retraiter_un(rel, trouve["url"])
                    noter_tags(nom, trouve.get("tags") or [])
                    noter_source(trouve["url"], rel)
                    T["trouvees"] += 1
                except Exception as e:
                    print(f"retraitement {nom} : {e!r}", flush=True); T["introuvables"] += 1
            else:
                T["introuvables"] += 1
            T["fait"] += 1
        print(f"[{time.strftime('%H:%M:%S')}] amélioration de la collection : {T['trouvees']} retraitée(s), {T['introuvables']} laissée(s) telles quelles", flush=True)
    finally:
        T["en_cours"] = False

def nom_fichier(titre, artiste):
    return f"{C.clean(artiste, 30)} - {C.clean(titre)}.jpg" if artiste else f"{C.clean(titre)}.jpg"

SOURCES_JSON = os.path.join(HERE, "sources.json")
META_JSON = os.path.join(HERE, "tags.json")
def lire_tags():
    try: return json.load(open(META_JSON))
    except Exception: return {}
def noter_tags(nom, tags):
    if not tags: return
    with ETAT_LOCK:
        m = lire_tags(); m[nom] = tags_propres(tags); ecrire_json(META_JSON, m)
def lire_sources():
    try: return json.load(open(SOURCES_JSON))
    except Exception: return {}
def noter_source(url, rel):
    with ETAT_LOCK:
        src = lire_sources(); src[url] = rel; ecrire_json(SOURCES_JSON, src)

def index_collection():
    """nom de fichier → thème, pour toute la collection."""
    idx = {}
    for t in themes():
        for r in t["images"]:
            idx[os.path.basename(r)] = {"nom": t["nom"], "id": t["id"], "rel": r}
    return idx

def ajouter(url, titre, artiste, theme):
    if not hote_ok(url):
        raise ValueError("source non reconnue")
    base = C.SAISONS_DIR if theme in SAISONS else C.OUT
    d = os.path.join(base, theme); os.makedirs(d, exist_ok=True)
    nom = nom_fichier(titre, artiste)
    p = os.path.join(d, nom)
    if os.path.exists(p):
        return os.path.relpath(p, HERE), False
    essais = [url]
    if "/thumb/" in url and "px-" in url:
        essais += [re.sub(r"/\d+px-", "/1920px-", url), re.sub(r"/\d+px-[^/]+$", "", url.replace("/thumb/", "/"))]
    if "~orig" in url:
        essais.append(url.replace("~orig", "~large"))
    for v in essais:
        try:
            telecharger_poli(v, p + ".tmp")
            if os.path.getsize(p + ".tmp") > 40 * 1024**2 and "~orig" in v:   # originaux NASA géants : version « large »
                continue
            break
        except urllib.error.HTTPError:
            continue
    else:
        raise ValueError("image indisponible sur le serveur d'origine")
    os.replace(p + ".tmp", p)
    convertir_fichier(p)
    noter_source(url, os.path.relpath(p, HERE))
    return os.path.relpath(p, HERE), True

# ---------- photos envoyées depuis le téléphone (ou le Finder) ----------
PHOTOS_THEME = "mes-photos"                       # thème par défaut, créé au premier envoi
IMPORTEES = os.path.join(HERE, "photos_importees.json")   # empreinte du fichier reçu → image de la collection
MAX_PHOTO = 60 * 1024**2
MONATE = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"]
MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"]

SECOURS_PHOTOS = os.path.join(HERE, ".sauvegardes", "photos-perso")   # copie que rien n'efface (ni la télécommande, ni « Supprimer »)
def mettre_photo_a_l_abri(p):
    try:
        os.makedirs(SECOURS_PHOTOS, exist_ok=True)
        dst = os.path.join(SECOURS_PHOTOS, os.path.basename(p))
        if os.path.exists(dst) and os.path.getsize(dst) != os.path.getsize(p):
            racine, ext = os.path.splitext(dst); dst = f"{racine} ({int(time.time())}){ext}"
        if not os.path.exists(dst):
            shutil.copy2(p, dst)
    except OSError as e:
        print(f"copie de sécurité impossible pour {p} : {e!r}", flush=True)

def abriter_photos_existantes():
    for rel in lire_importees().values():
        p = os.path.join(HERE, rel)
        if os.path.exists(p):
            mettre_photo_a_l_abri(p)

def lire_importees():
    try: return json.load(open(IMPORTEES))
    except Exception: return {}

def importer_photo(data, theme, quand=None):
    """Ajoute une photo personnelle à la collection, mise au format Frame comme le reste
    (3840×2160 sans recadrage, sRGB, une seule compression JPEG). Renvoie (rel, nouvelle ?)."""
    import datetime
    if not data:
        raise ValueError("photo vide")
    if theme != PHOTOS_THEME and theme not in {t["id"] for t in themes()}:
        raise ValueError("thème inconnu")
    empreinte = hashlib.sha1(data).hexdigest()
    deja = lire_importees().get(empreinte)
    if deja and os.path.exists(os.path.join(HERE, deja)):
        return deja, False                                   # même photo envoyée deux fois
    travail = os.path.join(HERE, ".cache", "import"); os.makedirs(travail, exist_ok=True)
    tmp = os.path.join(travail, f"{empreinte[:16]}.{threading.get_ident()}.jpg")
    try:
        with open(tmp, "wb") as f:
            f.write(data)
        convertir_fichier(tmp)
        with open(tmp, "rb") as f:
            debut = f.read(2)
        if debut != b"\xff\xd8" or C.dims(tmp) != (3840, 2160):
            raise ValueError("format de photo non reconnu")
        try:
            t = datetime.datetime.fromtimestamp(float(quand) / 1000) if quand else datetime.datetime.now()
        except (TypeError, ValueError, OverflowError, OSError):
            t = datetime.datetime.now()
        if langue() == "de":
            racine = f"Foto vom {t.day}. {MONATE[t.month - 1]} {t.year}, {t.hour}.{t.minute:02d} Uhr"
        else:
            racine = f"Photo du {t.day} {MOIS[t.month - 1]} {t.year} à {t.hour}h{t.minute:02d}"
        base = C.SAISONS_DIR if theme in SAISONS else C.OUT
        d = os.path.join(base, theme); os.makedirs(d, exist_ok=True)
        with ETAT_LOCK:
            n = 1; p = os.path.join(d, racine + ".jpg")
            while os.path.exists(p):
                n += 1; p = os.path.join(d, f"{racine} {n}.jpg")
            os.replace(tmp, p)                               # l'image n'apparaît qu'une fois prête
            rel = os.path.relpath(p, HERE)
            m = lire_importees(); m[empreinte] = rel; ecrire_json(IMPORTEES, m)
        mettre_photo_a_l_abri(p)
        print(f"[{time.strftime('%H:%M:%S')}] photo importée : {rel}", flush=True)
        return rel, True
    finally:
        try: os.remove(tmp)
        except FileNotFoundError: pass

def recherche_multi(texte, src_def="tout", page=1):
    """Plusieurs recherches séparées par « | », chacune pouvant préciser sa source (« nasa:galaxy »)."""
    sous = []
    for morceau in [m.strip() for m in texte.split("|") if m.strip()]:
        tete = morceau.split(":", 1)[0]
        if ":" in morceau and tete in RECHERCHES:
            sous.append((tete, morceau.split(":", 1)[1].strip()))
        else:
            sous.append((src_def, morceau))
    if len(sous) > 1:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(6) as ex:
            listes = list(ex.map(lambda st: rech_sure(RECHERCHES[st[0]])(st[1], page), sous))
        res, vus = [], set()
        for i in range(max(map(len, listes), default=0)):
            for l in listes:
                if i < len(l):
                    cle = sans_accent(f"{l[i].get('titre')}|{l[i].get('artiste')}")
                    if cle not in vus:
                        vus.add(cle); res.append(l[i])
    else:
        res = RECHERCHES[sous[0][0]](sous[0][1], page) if sous else []
    return res, sous

PERSO = os.path.join(HERE, "collections_perso.json")
def lire_perso():
    try: return json.load(open(PERSO))
    except Exception: return []
def ecrire_perso(l):
    ecrire_json(PERSO, l, indent=1)

COUV = os.path.join(HERE, ".cache", "couvertures.json")
def couverture(texte):
    try: cache = json.load(open(COUV))
    except Exception: cache = {}
    if texte in cache:
        return cache[texte]
    res, _ = recherche_multi(texte, "tout", 1)
    choix = next((r for r in res if r.get("paysage")), res[0] if res else None)
    v = (choix or {}).get("apercu") or (choix or {}).get("vignette")
    if v:
        cache[texte] = v
        os.makedirs(os.path.dirname(COUV), exist_ok=True)
        with ETAT_LOCK:
            try: tout = json.load(open(COUV))
            except Exception: tout = {}
            tout[texte] = v; ecrire_json(COUV, tout)
    return v

# ---------- vignettes distantes (proxy) ----------
HOTES_OK = ("artic.edu", "clevelandart.org", "nasa.gov", "wikimedia.org", "smk.dk", "artsmia.org", "vam.ac.uk")
def hote_ok(u):
    h = urllib.parse.urlparse(u).hostname or ""
    return urllib.parse.urlparse(u).scheme in ("http", "https") and any(h == d or h.endswith("." + d) for d in HOTES_OK)
PROXY = os.path.join(HERE, ".cache", "proxy")
_LIMITE_WIKI = threading.Semaphore(2)   # Wikimedia refuse les demandes trop nombreuses

def telecharger_poli(v, dest, essais=4):
    """Téléchargement respectueux : file limitée pour Wikimedia, nouvel essai quand le serveur demande de patienter (429)."""
    wiki = "wikimedia.org" in (urllib.parse.urlparse(v).hostname or "")
    for n in range(essais):
        try:
            if wiki: _LIMITE_WIKI.acquire()
            try:
                with urllib.request.urlopen(urllib.request.Request(v, headers=C.UA), timeout=90) as r:   # les musées fabriquent parfois l'image 4K à la demande
                    open(dest, "wb").write(r.read())
                return True
            finally:
                if wiki: _LIMITE_WIKI.release()
        except urllib.error.HTTPError as e:
            if e.code in (429, 503) and n < essais - 1:
                attente = e.headers.get("Retry-After")
                time.sleep(min(6, float(attente)) if attente and attente.replace(".", "").isdigit() else 1.5 * (n + 1))
                continue
            raise
    return False

def proxy(u):
    if not hote_ok(u):
        raise ValueError("hôte refusé")
    os.makedirs(PROXY, exist_ok=True)
    f = os.path.join(PROXY, hashlib.md5(u.encode()).hexdigest())
    if not os.path.exists(f):
        essais = [u]
        if "/thumb/" in u and "px-" in u:
            essais.append(re.sub(r"/\d+px-", "/960px-", u))
        tmp = f"{f}.{threading.get_ident()}.tmp"
        try:
            for v in essais:
                try:
                    if telecharger_poli(v, tmp):
                        os.replace(tmp, f); break
                except urllib.error.HTTPError:
                    continue
            else:
                if not os.path.exists(f):   # un autre téléchargement a pu réussir entre-temps
                    raise ValueError("image indisponible")
        finally:
            if os.path.exists(tmp):
                try: os.remove(tmp)
                except OSError: pass
    return f

from concurrent.futures import ThreadPoolExecutor as _Pool
_POOL_PROXY = _Pool(6)
def precharger(urls):
    """Télécharge les vignettes en avance (en parallèle) pour qu'elles s'affichent instantanément."""
    for u in urls:
        def tache(v=u):
            try: proxy(v)
            except Exception: pass
        _POOL_PROXY.submit(tache)

_POOL_VIGN = _Pool(2)
def preparer_vignettes(rels=None):
    """Fabrique à l'avance les vignettes de la collection (au démarrage et après un ajout)."""
    if rels is None:
        rels = [r for t in themes() for r in t["images"]]
    for r in rels:
        def tache(x=r):
            try: vignette(x)
            except Exception: pass
        _POOL_VIGN.submit(tache)

def sans_accent(x):
    import unicodedata
    return "".join(c for c in unicodedata.normalize("NFD", str(x or "")) if unicodedata.category(c) != "Mn").lower()

# ---------- vignettes ----------
def vignette(rel):
    p = chemin_sur(rel)
    os.makedirs(CACHE, exist_ok=True)
    cle = hashlib.md5(f"{rel}{os.path.getmtime(p)}".encode()).hexdigest()
    v = os.path.join(CACHE, cle + ".jpg")
    if not os.path.exists(v):
        try:
            subprocess.run(["sips", "-Z", "480", "-s", "format", "jpeg", p, "--out", v], capture_output=True)
        except FileNotFoundError:
            return p
    return v if os.path.exists(v) else p

# ---------- code d'accès (appareils autres que le Mac) ----------
import hmac, secrets
ESSAIS = {}   # ip → (nombre d'échecs, instant de blocage)

def secret_acces():
    cfg = lire_config(); modif = False
    if not cfg.get("code_acces"):
        cfg["code_acces"] = f"{secrets.randbelow(10**6):06d}"; modif = True
    if not cfg.get("secret"):
        cfg["secret"] = secrets.token_hex(16); modif = True
    if modif: ecrire_config(cfg)
    return cfg["code_acces"], cfg["secret"]

def jeton_attendu():
    code, sec = secret_acces()
    return hmac.new(sec.encode(), code.encode(), hashlib.sha256).hexdigest()

PAGE_CONNEXION = """<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Ma Frame</title><link rel="apple-touch-icon" href="/icone-iphone.png?v=2"><meta name="apple-mobile-web-app-capable" content="yes">
<style>:root{--bg:#f2f2f7;--p:#fff;--t:#000;--m:#6c6c70;--a:#0066cc}@media (prefers-color-scheme:dark){:root{--bg:#000;--p:#1c1c1e;--t:#fff;--m:rgba(235,235,245,.66)}}
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:var(--bg);color:var(--t);font:17px -apple-system,BlinkMacSystemFont,sans-serif}
.c{background:var(--p);border-radius:16px;padding:28px 24px;width:min(340px,90vw);text-align:center}
img{width:64px;height:64px;border-radius:14px}h1{font-size:22px;margin:12px 0 4px}p{color:var(--m);font-size:14px;margin:0 0 18px}
input{width:100%;box-sizing:border-box;font:600 28px/1 ui-monospace,Menlo,monospace;letter-spacing:8px;text-align:center;padding:12px;border:0;border-radius:12px;background:rgba(120,120,128,.16);color:var(--t)}
button{margin-top:14px;width:100%;padding:12px;border:0;border-radius:12px;background:var(--a);color:#fff;font:600 17px -apple-system,sans-serif}
#e{color:#d70015;font-size:14px;min-height:20px;margin-top:10px}</style></head><body>
<form class="c" onsubmit="go(event)"><img src="/icone.png?v=2" alt=""><h1>Ma Frame</h1>
<p>Entre le code affiché sur ton Mac, dans Ma Frame → Télécommande.</p>
<label for="k" style="position:absolute;left:-9999px">Code d’accès</label>
<input id="k" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="••••••" autofocus>
<button>Se connecter</button><div id="e" role="alert"></div></form>
<script>async function go(ev){ev.preventDefault();const r=await fetch("/api/connexion",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code:document.getElementById("k").value.replace(/\\D/g,"")})});
const j=await r.json().catch(()=>({}));if(r.ok){location.replace("/")}else{document.getElementById("e").textContent=j.erreur||"Code incorrect"}}</script></body></html>"""

PAGE_CONNEXION = PAGE_CONNEXION.replace("Ma Frame → Télécommande", "Ma Frame → Réglages")
PAGE_CONNEXION_DE = (PAGE_CONNEXION.replace('<html lang="fr">', '<html lang="de">')
    .replace("Entre le code affiché sur ton Mac, dans Ma Frame → Réglages.", "Gib den Code ein, der auf deinem Mac in Ma Frame → Einstellungen steht.")
    .replace("Code d’accès", "Zugangscode").replace("Se connecter", "Anmelden").replace('j.erreur||"Code incorrect"', '(j.erreur==="Code incorrect"?"Falscher Code":j.erreur)||"Falscher Code"').replace("Ma Frame", "Meine FRAME"))

# ---------- serveur web ----------
class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def envoyer_json(self, obj, code=200):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

    def envoyer_fichier(self, p, ctype, cache=True):
        b = open(p, "rb").read()
        self.send_response(200); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(b)))
        if cache:
            self.send_header("Cache-Control", "max-age=86400")
        self.end_headers(); self.wfile.write(b)

    def corps(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")

    def do_GET(self):
        u = urllib.parse.urlparse(self.path); q = dict(urllib.parse.parse_qsl(u.query))
        if u.path not in ("/icone.png", "/icone-iphone.png", "/manifest.json") and not self.autorise():
            return self.refuser(u.path)
        try:
            if u.path in ("/", "/index.html"):
                b = open(os.path.join(HERE, "web", "index.html"), "rb").read().replace(b'<html lang="fr">', f'<html lang="{langue()}">'.encode(), 1)
                self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.send_header("Content-Length", str(len(b)))
                self.end_headers(); self.wfile.write(b); return
            if u.path == "/langue.js":
                return self.envoyer_fichier(os.path.join(HERE, "web", "langue.js"), "text/javascript; charset=utf-8", cache=False)
            if u.path == "/api/etat":
                cfg = lire_config(); env = lire_envoyees(); TAGS = lire_tags()
                ts = [{**{k: v for k, v in t.items() if k != "dossier"},
                       "images": [{"rel": r, "nom": os.path.basename(r).rsplit(".", 1)[0], "sur_tv": r in env,
                                   "tags": TAGS.get(os.path.basename(r), [])} for r in t["images"]]}
                      for t in themes(cfg)]
                return self.envoyer_json({"themes": ts, "saison_forcee": cfg.get("saison_forcee"), "diaporama": cfg.get("diaporama", "60"),
                                          "saisons_auto": C.saisons_du_moment(), "noms": NOMS, "tache": TACHE,
                                          "tv": {"ip": FA.IP, "joignable": tv_joignable(), "recherche": RECHERCHE_TV["en_cours"], "repond": CANAL_ART["ok"],
                                                 "autorisee": bool(FA.jeton()), "jumelage": JUMELAGE["en_cours"]}, "langue": langue(), "version": version_appli(), "adresse_tel": f"http://{ip_locale()}:{PORT}",
                                          "code_acces": secret_acces()[0] if self.depuis_le_mac() else None})
            if u.path == "/icone-iphone.png":
                return self.envoyer_fichier(os.path.join(HERE, "web", "icone-iphone.png"), "image/png")
            if u.path == "/icone.png":
                return self.envoyer_fichier(os.path.join(HERE, "web", "icone.png"), "image/png")
            if u.path == "/manifest.json":
                nom_app = "Meine FRAME" if langue() == "de" else "Ma Frame"
                return self.envoyer_json({"name": nom_app, "short_name": nom_app, "start_url": "/", "display": "standalone",
                                          "background_color": "#000000", "theme_color": "#000000",
                                          "icons": [{"src": "/icone.png?v=2", "sizes": "512x512", "type": "image/png"}, {"src": "/icone-iphone.png?v=2", "sizes": "180x180", "type": "image/png"}]})
            if u.path == "/api/art-reglages":
                return self.envoyer_json({"reglages": tv_lire_reglages_art()})
            if u.path == "/api/clavier":
                TC.preparer()
                return self.envoyer_json({"ouvert": TC.ime, "champ": TC.champ, "liaison": TC.ws is not None})
            if u.path == "/api/retraitement":
                return self.envoyer_json({**RETRAIT, "disponibles": len([1 for u, r in lire_sources().items() if os.path.exists(os.path.join(HERE, r))]),
                                          "tout": RETRAIT_TOUT})
            if u.path == "/api/tache":
                return self.envoyer_json(TACHE)
            if u.path == "/vignette":
                return self.envoyer_fichier(vignette(q["rel"]), "image/jpeg")
            if u.path == "/image":
                return self.envoyer_fichier(chemin_sur(q["rel"]), "image/jpeg")
            if u.path == "/api/collections":
                return self.envoyer_json(lire_perso())
            if u.path == "/api/masquees":
                return self.envoyer_json(lire_config().get("cartes_masquees", []))
            if u.path == "/api/couverture":
                return self.envoyer_json({"image": couverture(q.get("q", ""))})
            if u.path == "/proxy":
                return self.envoyer_fichier(proxy(q["u"]), "image/jpeg")
            if u.path == "/api/rechercher":
                page = int(q.get("page", 1))
                res, sous = recherche_multi(q.get("q", ""), q.get("source", "tout"), page)
                groupes = [sans_accent(t).split() for _, t in sous]
                for r in res:
                    texte = sans_accent(f"{r.get('titre')} {r.get('artiste')}")
                    r["exact"] = any(g and all(m in texte for m in g) for g in groupes)
                idx = index_collection(); src = lire_sources()
                for r in res:
                    nom = nom_fichier(r.get("titre") or "sans titre", r.get("artiste") or "")
                    rel = src.get(r.get("url"))
                    if rel and os.path.exists(os.path.join(HERE, rel)):
                        nom = os.path.basename(rel)
                    info = idx.get(nom) or {}
                    r["deja"], r["deja_id"], r["deja_rel"] = info.get("nom"), info.get("id"), info.get("rel")
                res.sort(key=lambda r: not r["exact"])
                precharger([r.get("vignette") for r in res[:30] if r.get("vignette")])
                return self.envoyer_json({"resultats": res, "exacts": sum(r["exact"] for r in res)})
            self.send_error(404)
        except Exception as e:
            traceback.print_exc(); self.envoyer_json({"erreur": message_clair(e)}, 500)

    def depuis_le_mac(self):
        return self.client_address[0] in ("127.0.0.1", "::1", "::ffff:127.0.0.1")

    def autorise(self):
        if self.depuis_le_mac():
            return True
        for morceau in (self.headers.get("Cookie") or "").split(";"):
            k, _, v = morceau.strip().partition("=")
            if k == "maframe" and hmac.compare_digest(v, jeton_attendu()):
                return True
        return False

    def refuser(self, chemin):
        if chemin in ("/", "/index.html"):
            b = (PAGE_CONNEXION_DE if langue() == "de" else PAGE_CONNEXION).encode()
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
        else:
            self.envoyer_json({"erreur": "code d’accès requis"}, 401)

    def origine_ok(self):
        """N'accepte que les commandes venant de Ma Frame elle-même (même adresse), jamais d'un autre site."""
        hote = (self.headers.get("Host") or "").lower()
        origine = self.headers.get("Origin")
        if origine is not None:
            return urllib.parse.urlparse(origine).netloc.lower() == hote
        site = self.headers.get("Sec-Fetch-Site")
        if site is not None:
            return site in ("same-origin", "none")
        return True  # outils en ligne de commande sur le Mac

    def do_POST(self):
        u = urllib.parse.urlparse(self.path); q = dict(urllib.parse.parse_qsl(u.query))
        ctype = self.headers.get("Content-Type") or ""
        envoi_photo = u.path == "/api/importer-photo" and ctype.startswith("image/")
        if not self.origine_ok() or ("application/json" not in ctype and not envoi_photo):
            print(f"[{time.strftime('%H:%M:%S')}] commande refusée : origine {self.headers.get('Origin')!r} vers {u.path}", flush=True)
            return self.envoyer_json({"erreur": "commande refusée"}, 403)
        if u.path == "/api/connexion":
            ip = self.client_address[0]; n, bloque = ESSAIS.get(ip, (0, 0))
            if time.time() < bloque:
                return self.envoyer_json({"erreur": f"Trop d’essais. Réessaie dans {int(bloque - time.time())} s."}, 429)
            code, _ = secret_acces()
            if hmac.compare_digest(str(self.corps().get("code", "")), code):
                ESSAIS.pop(ip, None)
                b = json.dumps({"ok": True}).encode()
                self.send_response(200); self.send_header("Content-Type", "application/json")
                self.send_header("Set-Cookie", f"maframe={jeton_attendu()}; Max-Age=31536000; Path=/; HttpOnly; SameSite=Strict")
                self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
                return
            n += 1
            ESSAIS[ip] = (n, time.time() + min(300, 30 * 2 ** (n - 5)) if n >= 5 else 0)
            print(f"[{time.strftime('%H:%M:%S')}] code d’accès incorrect depuis {ip} ({n} essai(s))", flush=True)
            return self.envoyer_json({"erreur": "Code incorrect"}, 403)
        if not self.autorise():
            return self.refuser(u.path)
        verrou = u.path in ROUTES_ETAT   # lecture + modification + écriture d'un seul tenant
        if verrou: ETAT_LOCK.acquire()
        try:
            if envoi_photo:
                n = int(self.headers.get("Content-Length") or 0)
                if n <= 0 or n > MAX_PHOTO:
                    print(f"[{time.strftime('%H:%M:%S')}] photo refusée : {n // 1024**2} Mo", flush=True)
                    return self.envoyer_json({"erreur": "photo trop lourde (60 Mo au plus)"}, 413)
                rel, nouveau = importer_photo(self.rfile.read(n), q.get("theme") or PHOTOS_THEME, q.get("date"))
                preparer_vignettes([rel])
                return self.envoyer_json({"ok": True, "rel": rel, "nouveau": nouveau})
            b = self.corps(); env = lire_envoyees()
            if u.path == "/api/retraiter-tout":
                if not self.depuis_le_mac():
                    return self.envoyer_json({"erreur": "uniquement depuis le Mac"}, 403)
                if not RETRAIT_TOUT["en_cours"] and not RETRAIT["en_cours"]:
                    threading.Thread(target=retraiter_tout, daemon=True).start()
                return self.envoyer_json({"ok": True})
            if u.path == "/api/retraiter":
                if not self.depuis_le_mac():
                    return self.envoyer_json({"erreur": "uniquement depuis le Mac"}, 403)
                if not RETRAIT["en_cours"]:
                    threading.Thread(target=retraiter_ajoutees, daemon=True).start()
                return self.envoyer_json({"ok": True, **RETRAIT})
            if u.path == "/api/nouveau-code":
                if not self.depuis_le_mac():
                    return self.envoyer_json({"erreur": "uniquement depuis le Mac"}, 403)
                cfg = lire_config(); cfg["code_acces"] = f"{secrets.randbelow(10**6):06d}"; ecrire_config(cfg)
                return self.envoyer_json({"ok": True, "code": cfg["code_acces"]})
            if u.path == "/api/masquees":
                cfg = lire_config(); m = set(cfg.get("cartes_masquees", []))
                if b.get("tout_reafficher"): m = set()
                elif b.get("masquer"): m.add(b["cle"])
                else: m.discard(b["cle"])
                cfg["cartes_masquees"] = sorted(m); ecrire_config(cfg)
                return self.envoyer_json({"ok": True})
            if u.path == "/api/collections":
                l = lire_perso(); act = b.get("action")
                if act == "supprimer":
                    l = [c for c in l if c.get("id") != b["id"]]
                elif act == "ordre":
                    rang = {i: n for n, i in enumerate(b.get("ids", []))}
                    l = sorted(l, key=lambda c: rang.get(c.get("id"), 999))
                else:
                    mots = [m.strip() for m in str(b.get("mots", "")).replace("\n", ",").split(",") if m.strip()]
                    if not b.get("nom") or not mots:
                        raise ValueError("Il faut un nom et au moins un mot-clé")
                    c = {"id": b.get("id") or hashlib.md5(f"{b['nom']}{time.time()}".encode()).hexdigest()[:8],
                         "nom": b["nom"].strip()[:40], "d": str(b.get("d", "")).strip()[:160], "groupe": "mes-cartes",
                         "a": ", ".join(mots[:4]), "q": "|".join(mots[:8]), "mots": mots}
                    if act == "modifier" and any(x.get("id") == c["id"] for x in l):
                        l = [c if x.get("id") == c["id"] else x for x in l]   # remplacée sur place
                    else:
                        l = l + [c]
                ecrire_perso(l)
                return self.envoyer_json({"ok": True})
            if u.path == "/api/arreter":
                self.envoyer_json({"ok": True})
                threading.Timer(0.5, lambda: os._exit(0)).start()
                return
            if u.path == "/api/supprimer":
                rels = b.get("rels") or [b["rel"]]
                cids = [env[r] for r in rels if r in env]
                if cids and not b.get("local_seulement"):
                    tv_supprimer(cids)
                for r in rels:
                    env.pop(r, None)
                    try: os.remove(chemin_sur(r))
                    except FileNotFoundError: pass
                ecrire_envoyees(env)
                TACHE["a_confirmer"] = [r for r in TACHE["a_confirmer"] if r not in rels]
                return self.envoyer_json({"ok": True})
            if u.path == "/api/garder":     # images retirées de la TV mais que l'on garde quand même
                TACHE["a_confirmer"] = [r for r in TACHE["a_confirmer"] if r not in b["rels"]]
                return self.envoyer_json({"ok": True})
            if u.path == "/api/afficher":
                assurer_mode_art()
                cid = env.get(b["rel"]) or tv_upload(b["rel"])
                tv_afficher(cid); return self.envoyer_json({"ok": True})
            if u.path == "/api/deplacer":
                src = chemin_sur(b["rel"]); base = C.SAISONS_DIR if b["theme"] in SAISONS else C.OUT
                d = os.path.join(base, b["theme"]); os.makedirs(d, exist_ok=True)
                dst = os.path.join(d, os.path.basename(src)); shutil.move(src, dst)
                nrel = os.path.relpath(dst, HERE)
                if b["rel"] in env:
                    env[nrel] = env.pop(b["rel"]); ecrire_envoyees(env)
                with ETAT_LOCK:
                    m = lire_importees()
                    if b["rel"] in m.values():
                        ecrire_json(IMPORTEES, {k: (nrel if v == b["rel"] else v) for k, v in m.items()})
                return self.envoyer_json({"ok": True, "rel": nrel})
            if u.path == "/api/theme":
                cfg = lire_config(); cfg["actifs"][b["id"]] = bool(b["actif"]); ecrire_config(cfg)
                return self.envoyer_json({"ok": True})
            if u.path == "/api/nouveau-theme":
                joli = C.clean(b.get("nom"), 40)
                nom = joli.lower().replace(" ", "-")
                if nom in SAISONS or nom == "sans-titre":
                    raise ValueError("choisis un autre nom de dossier")
                os.makedirs(os.path.join(C.OUT, nom), exist_ok=True)
                if nom not in NOMS:
                    noms = lire_json(NOMS_PERSO, {}); noms.setdefault(nom, joli); ecrire_json(NOMS_PERSO, noms)
                return self.envoyer_json({"ok": True, "id": nom, "nom": nom_theme(nom)})
            if u.path == "/api/langue":
                cfg = lire_config(); cfg["langue"] = "de" if b.get("langue") == "de" else "fr"; ecrire_config(cfg)
                return self.envoyer_json({"ok": True})
            if u.path == "/api/saison":
                cfg = lire_config(); cfg["saison_forcee"] = b.get("saison") or None
                for t in SAISONS: cfg["actifs"].pop(t, None)
                ecrire_config(cfg)
                return self.envoyer_json({"ok": True})
            if u.path == "/api/synchroniser":
                if not TACHE["en_cours"]:
                    threading.Thread(target=synchroniser, daemon=True).start()
                return self.envoyer_json({"ok": True})
            if u.path == "/api/ajouter":
                rel, nouveau = ajouter(b["url"], b.get("titre") or "sans titre", b.get("artiste") or "", b["theme"])
                noter_tags(os.path.basename(rel), b.get("tags") or [])
                preparer_vignettes([rel])
                return self.envoyer_json({"ok": True, "rel": rel, "nouveau": nouveau})
            if u.path == "/api/art-reglages":
                tv_regler_art(b["item"], b["valeur"])
                return self.envoyer_json({"ok": True})
            if u.path == "/api/souris":
                if b.get("clic"): TC.clic(b.get("clic") if isinstance(b.get("clic"), int) else 1)
                else: TC.deplacer(b.get("dx", 0), b.get("dy", 0))
                return self.envoyer_json({"ok": True})
            if u.path == "/api/texte":
                TC.texte(str(b.get("texte", ""))[:500], bool(b.get("valider")))
                return self.envoyer_json({"ok": True, "clavier_tv": TC.ime})
            if u.path == "/api/telecommande":
                a = b["action"]
                if a.startswith("page_"):
                    TC.defiler(a); return self.envoyer_json({"ok": True})
                if a == "art_on": assurer_mode_art(); tv_artmode(True)
                elif a == "art_off": tv_artmode(False)
                elif a == "diaporama": return self.envoyer_json({"ok": True, **tv_diaporama(b.get("valeur", "60"))})
                else:
                    touches = {"power": "KEY_POWER", "vol_plus": "KEY_VOLUP", "vol_moins": "KEY_VOLDOWN", "muet": "KEY_MUTE",
                               "home": "KEY_HOME", "retour": "KEY_RETURN", "ok": "KEY_ENTER", "haut": "KEY_UP", "bas": "KEY_DOWN",
                               "gauche": "KEY_LEFT", "droite": "KEY_RIGHT", "lecture": "KEY_PLAY", "pause": "KEY_PAUSE", "source": "KEY_SOURCE",
                               "chaine_plus": "KEY_CHUP", "chaine_moins": "KEY_CHDOWN", "menu": "KEY_MENU"}
                    tv_touche(touches[a])
                return self.envoyer_json({"ok": True})
            self.send_error(404)
        except Exception as e:
            traceback.print_exc(); self.envoyer_json({"erreur": message_clair(e)}, 500)
        finally:
            if verrou: ETAT_LOCK.release()

def ip_locale():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(("8.8.8.8", 80)); ip = s.getsockname()[0]; s.close(); return ip
    except Exception:
        return "127.0.0.1"

if __name__ == "__main__":
    FA.IP = lire_config().get("tv_ip") or FA.IP
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), H)
    threading.Thread(target=surveillance, daemon=True).start()
    threading.Thread(target=premier_lancement, daemon=True).start()
    threading.Thread(target=preparer_vignettes, daemon=True).start()
    threading.Thread(target=abriter_photos_existantes, daemon=True).start()
    print(f"[{time.strftime('%H:%M:%S')}] 🖼  Ma Frame est lancée (pid {os.getpid()})", flush=True)
    print(f"   Sur ce Mac       : http://localhost:{PORT}")
    print(f"   Sur ton téléphone : http://{ip_locale()}:{PORT}  (même Wi-Fi)")
    print("   Laisse cette fenêtre ouverte. Pour arrêter : Ctrl + C")
    if "--sans-navigateur" not in sys.argv:
        threading.Timer(1.0, lambda: webbrowser.open(f"http://localhost:{PORT}")).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêt.")
