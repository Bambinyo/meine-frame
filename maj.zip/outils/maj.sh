#!/bin/bash
# Meine FRAME – automatische Aktualisierung (läuft alle 6 Stunden im Hintergrund).
# Ersetzt nur den Programmcode. Einstellungen, Fernseher-Freigabe, Bilder und Fotos bleiben unangetastet.
# Startet die neue Version nicht, wird automatisch die vorherige wiederhergestellt.
# (FR : mise à jour automatique. Seul le code est remplacé ; retour arrière si la nouvelle version ne démarre pas.)
DEPOT="Bambinyo/meine-frame"
BASE="${MAJ_BASE:-https://raw.githubusercontent.com/$DEPOT/main}"
ZIEL="$HOME/frame-tv"
MAJ="$ZIEL/.maj"
LOG="$MAJ/maj.log"
PY="$ZIEL/.venv/bin/python"
DIENST="gui/$(id -u)/perso.maframe.serveur"
# La liste complète des fichiers remplaçables. Rien d'autre n'est jamais écrit.
FICHIERS="VERSION app.py collection.py frame_art.py web/index.html web/langue.js web/icone.png web/icone-iphone.png app-mac/main.swift app-mac/Info.plist app-mac/installer.sh outils/installieren.sh outils/maj.sh"
export PATH="/usr/bin:/bin:/usr/sbin:/sbin${MAJ_PATH:+:$MAJ_PATH}"

# Ce script peut se remplacer lui-même : on travaille toujours depuis une copie.
if [ -z "$MAJ_COPIE" ]; then
  T0="$(mktemp -d)"; cp "$0" "$T0/maj.sh"
  MAJ_COPIE="$T0" exec /bin/bash "$T0/maj.sh" "$@"
fi
T="$MAJ_COPIE"
mkdir -p "$MAJ"
log(){ echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"; }
find "$MAJ" -maxdepth 1 -name verrou -mmin +60 -exec rmdir {} \; 2>/dev/null
mkdir "$MAJ/verrou" 2>/dev/null || exit 0
trap 'rmdir "$MAJ/verrou" 2>/dev/null; rm -rf "$T"' EXIT
[ -z "$MAJ_BASE" ] && case "$DEPOT" in A_REMPLIR*) exit 0;; esac

LOCAL="$(tr -dc 0-9 < "$ZIEL/VERSION" 2>/dev/null)"; LOCAL="${LOCAL:-0}"
curl -fsSL --max-time 30 "$BASE/version.json" -o "$T/version.json" 2>/dev/null || exit 0   # hors ligne : on réessaiera
read -r NEU SHA <<<"$("$PY" -c 'import json,sys; d=json.load(open(sys.argv[1])); print(int(d["version"]), d["sha256"])' "$T/version.json" 2>/dev/null)"
[ -n "$NEU" ] && [ -n "$SHA" ] || { log "version.json illisible"; exit 0; }
[ "$NEU" -gt "$LOCAL" ] || exit 0
[ "$(cat "$MAJ/ignorer" 2>/dev/null)" = "$NEU" ] && exit 0   # version déjà essayée et refusée

# Pas pendant un envoi vers la TV ou le jumelage : on réessaiera plus tard.
"$PY" - <<'PYEOF' 2>/dev/null || exit 0
import json, urllib.request, sys
try:
    e = json.load(urllib.request.urlopen("http://127.0.0.1:8765/api/etat", timeout=5))
except Exception:
    sys.exit(0)   # moteur arrêté : la mise à jour peut justement le réparer
sys.exit(1 if (e.get("tache") or {}).get("en_cours") or (e.get("tv") or {}).get("jumelage") else 0)
PYEOF

log "Nouvelle version $NEU (installée : $LOCAL)"
curl -fsSL --max-time 300 "$BASE/maj.zip" -o "$T/maj.zip" || { log "téléchargement impossible"; exit 0; }
[ "$(shasum -a 256 "$T/maj.zip" | cut -d' ' -f1)" = "$SHA" ] || { log "empreinte incorrecte, abandon"; exit 0; }
mkdir "$T/neu" && unzip -q "$T/maj.zip" -d "$T/neu" || { log "zip illisible"; exit 0; }

# Contrôles avant de toucher à quoi que ce soit
INATTENDU="$(cd "$T/neu" && find . -type f | sed 's|^\./||' | while read -r f; do case " $FICHIERS " in *" $f "*) ;; *) echo "$f";; esac; done)"
[ -z "$INATTENDU" ] || { log "fichiers inattendus, abandon : $INATTENDU"; echo "$NEU" > "$MAJ/ignorer"; exit 0; }
for f in $FICHIERS; do [ -f "$T/neu/$f" ] || { log "fichier manquant : $f"; echo "$NEU" > "$MAJ/ignorer"; exit 0; }; done
for f in app.py collection.py frame_art.py; do
  "$PY" -c 'import ast,sys; ast.parse(open(sys.argv[1]).read())' "$T/neu/$f" 2>>"$LOG" || { log "erreur de syntaxe dans $f, abandon"; echo "$NEU" > "$MAJ/ignorer"; exit 0; }
done
APPLI=""
if ! cmp -s "$T/neu/app-mac/main.swift" "$ZIEL/app-mac/main.swift" || ! cmp -s "$T/neu/app-mac/Info.plist" "$ZIEL/app-mac/Info.plist"; then
  swiftc -O "$T/neu/app-mac/main.swift" -o "$T/MaFrame" 2>>"$LOG" || { log "compilation impossible, abandon"; echo "$NEU" > "$MAJ/ignorer"; exit 0; }
  APPLI=1
fi

# Sauvegarde de la version actuelle, puis remplacement
rm -rf "$MAJ/precedente"; mkdir -p "$MAJ/precedente"
for f in $FICHIERS; do
  [ -f "$ZIEL/$f" ] && { mkdir -p "$MAJ/precedente/$(dirname "$f")"; cp -p "$ZIEL/$f" "$MAJ/precedente/$f"; }
done
for f in $FICHIERS; do mkdir -p "$ZIEL/$(dirname "$f")"; cp "$T/neu/$f" "$ZIEL/$f.maj-tmp" && mv -f "$ZIEL/$f.maj-tmp" "$ZIEL/$f"; done
launchctl kickstart -k "$DIENST" 2>>"$LOG"

# La nouvelle version doit répondre ET annoncer le bon numéro (et pas l'ancien serveur pas encore arrêté)
repond(){ for i in $(seq 1 40); do sleep 1
  "$PY" -c 'import json,sys,urllib.request; e=json.load(urllib.request.urlopen("http://127.0.0.1:8765/api/etat",timeout=2)); v=(e.get("version") or {}).get("numero"); sys.exit(0 if not sys.argv[1] or v==sys.argv[1] else 1)' "$1" 2>/dev/null && return 0
done; return 1; }
if ! repond "$NEU"; then
  log "la version $NEU ne démarre pas : retour à la version précédente"
  for f in $FICHIERS; do
    if [ -f "$MAJ/precedente/$f" ]; then cp -p "$MAJ/precedente/$f" "$ZIEL/$f"; else rm -f "$ZIEL/$f"; fi
  done
  echo "$NEU" > "$MAJ/ignorer"
  launchctl kickstart -k "$DIENST" 2>>"$LOG"
  repond "" && log "version précédente relancée" || log "ATTENTION : la version précédente ne répond pas non plus"
  exit 0
fi

# L'appli Mac, seulement si son code a changé (elle reste ouverte ; la nouvelle sert au prochain lancement)
if [ -n "$APPLI" ]; then
  NOM="Ma Frame"; grep -q '"langue": *"de"' "$ZIEL/config.json" 2>/dev/null && NOM="Meine FRAME"
  APP="$HOME/Applications/$NOM.app"
  if [ -d "$APP" ]; then
    cp "$T/MaFrame" "$APP/Contents/MacOS/MaFrame.neu" && mv -f "$APP/Contents/MacOS/MaFrame.neu" "$APP/Contents/MacOS/MaFrame"
    cp "$ZIEL/app-mac/Info.plist" "$APP/Contents/Info.plist"
    /usr/libexec/PlistBuddy -c "Set :CFBundleName $NOM" -c "Set :CFBundleDisplayName $NOM" "$APP/Contents/Info.plist"
  fi
fi
date '+%Y-%m-%d %H:%M' > "$MAJ/derniere.txt"
rm -f "$MAJ/ignorer"
log "version $NEU installée"
