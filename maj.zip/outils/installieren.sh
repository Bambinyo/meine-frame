#!/bin/bash
# Meine FRAME – Installation (und Aktualisierung) auf einem Mac.
# Aufruf im Terminal:  bash ~/Downloads/MeineFRAME/installieren.sh
# Kopiert die App nach ~/frame-tv, richtet Python ein, baut die Mac-App und startet sie.
# Bei einer Aktualisierung bleiben Sammlung, Einstellungen und Freigabe des Fernsehers erhalten.
set -e
QUELLE="$(cd "$(dirname "$0")" && pwd)"
ZIEL="$HOME/frame-tv"
echo ""
echo "🖼  Meine FRAME wird installiert …"
echo ""

# 1. Apple-Entwicklerwerkzeuge (für Python und den Bau der App)
if ! xcode-select -p >/dev/null 2>&1 || ! /usr/bin/xcrun --find swiftc >/dev/null 2>&1; then
  echo "Zuerst braucht dein Mac die kostenlosen „Befehlszeilenwerkzeuge“ von Apple."
  echo "Gleich erscheint ein Fenster: Klicke auf „Installieren“ und warte, bis es fertig ist (5–15 Minuten)."
  echo "Danach fügst du denselben Befehl noch einmal ins Terminal ein."
  xcode-select --install 2>/dev/null || true
  exit 0
fi

# 2. Dateien kopieren (persönliche Daten bleiben unangetastet)
echo "1/4 Dateien werden kopiert …"
mkdir -p "$ZIEL/web" "$ZIEL/app-mac" "$ZIEL/outils" "$ZIEL/.cache" "$ZIEL/oeuvres" "$ZIEL/saisons"
cp "$QUELLE"/app.py "$QUELLE"/collection.py "$QUELLE"/frame_art.py "$ZIEL/"
cp "$QUELLE"/web/index.html "$QUELLE"/web/langue.js "$QUELLE"/web/icone.png "$QUELLE"/web/icone-iphone.png "$ZIEL/web/"
cp "$QUELLE"/app-mac/main.swift "$QUELLE"/app-mac/Info.plist "$QUELLE"/app-mac/installer.sh "$ZIEL/app-mac/"
cp "$QUELLE"/installieren.sh "$QUELLE"/maj.sh "$ZIEL/outils/"
[ -f "$QUELLE/VERSION" ] && cp "$QUELLE/VERSION" "$ZIEL/VERSION"
if [ ! -f "$ZIEL/config.json" ]; then
  printf '{\n "actifs": {},\n "saison_forcee": null,\n "langue": "de"\n}\n' > "$ZIEL/config.json"
fi
xattr -dr com.apple.quarantine "$ZIEL" 2>/dev/null || true

# 3. Python einrichten
echo "2/4 Python wird eingerichtet (1 Minute) …"
if [ ! -x "$ZIEL/.venv/bin/python" ]; then
  /usr/bin/python3 -m venv "$ZIEL/.venv"
fi
"$ZIEL/.venv/bin/python" -m pip install --quiet --disable-pip-version-check websocket-client

# 4. Ins Dock legen (nur beim ersten Mal), Mac-App bauen, Hintergrunddienst einrichten, App starten
if ! defaults read com.apple.dock persistent-apps 2>/dev/null | grep -q "Meine%20FRAME.app"; then
  defaults write com.apple.dock persistent-apps -array-add "<dict><key>tile-data</key><dict><key>file-data</key><dict><key>_CFURLString</key><string>file://$HOME/Applications/Meine%20FRAME.app/</string><key>_CFURLStringType</key><integer>15</integer></dict></dict></dict>"
fi
bash "$ZIEL/app-mac/installer.sh"

# 5. Automatische Aktualisierung (alle 6 Stunden, ganz im Hintergrund)
PLIST_MAJ="$HOME/Library/LaunchAgents/perso.maframe.maj.plist"
cat > "$PLIST_MAJ" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>perso.maframe.maj</string>
<key>ProgramArguments</key><array><string>/bin/bash</string><string>$ZIEL/outils/maj.sh</string></array>
<key>StartInterval</key><integer>21600</integer>
<key>RunAtLoad</key><true/>
<key>LowPriorityIO</key><true/>
<key>Nice</key><integer>10</integer>
</dict></plist>
PL
launchctl bootout "gui/$(id -u)/perso.maframe.maj" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$PLIST_MAJ"

echo ""
echo "✅ Fertig! Meine FRAME ist geöffnet und liegt im Dock."
echo ""
echo "Jetzt noch:"
echo "  • Fernseher einschalten (gleiches WLAN wie der Mac)."
echo "  • Auf dem Fernseher erscheint eine Anfrage von „Meine FRAME“: mit der Fernbedienung „Zulassen“ wählen."
echo "  • Fragt der Mac, ob Python Geräte im lokalen Netzwerk finden darf: „Erlauben“ klicken."
echo "    (Kommt keine Frage und findet Meine FRAME den Fernseher nicht: Systemeinstellungen › Datenschutz & Sicherheit"
echo "     › Lokales Netzwerk › „Python“ einschalten. Siehe Anleitung.)"
echo "Danach lädt Meine FRAME von selbst eine Startsammlung und schickt sie auf den Fernseher."
echo ""
