// Ma Frame : langues de l'interface.
// Le français reste le texte de référence, écrit tel quel dans index.html.
// En allemand, chaque texte affiché (y compris ceux ajoutés plus tard par l'appli) est remplacé
// à la volée grâce au dictionnaire DE et aux MOTIFS (textes avec des nombres ou des noms).
// La langue vient de <html lang="…">, posé par le moteur d'après config.json (« langue »).
(function(){
"use strict";
const LANGUE = (document.documentElement.getAttribute("lang") || "fr").slice(0, 2);
window.LANGUE = LANGUE;
window.tr = s => s;                       // sans traduction : le texte reste tel quel
window.SYN_DE = null; window.DE_EN = null;
if(LANGUE !== "de") return;

// ---------- Textes fixes ----------
const DE = {
  // Navigation et en-tête
  "Collection": "Sammlung", "Ajouter": "Hinzufügen", "Télécommande": "Fernbedienung", "Réglages": "Einstellungen",
  "Thèmes": "Themen", "Navigation": "Navigation", "Réglages (⌘,)": "Einstellungen (⌘,)",
  "Collection · Ma Frame": "Sammlung · Ma Frame", "Ajouter · Ma Frame": "Hinzufügen · Ma Frame",
  "Télécommande · Ma Frame": "Fernbedienung · Ma Frame", "Réglages · Ma Frame": "Einstellungen · Ma Frame",
  "Saison affichée sur la TV": "Jahreszeit auf dem Fernseher", "Saison affichée": "Angezeigte Jahreszeit",
  "Nouveau thème": "Neues Thema", "Synchroniser la TV maintenant": "Fernseher jetzt synchronisieren",
  "Comment ça marche ?": "Wie funktioniert das?", "Aide : comment ça marche": "Hilfe: So funktioniert’s",
  // État de la TV
  "Envoi au prochain mode Art": "Wird beim nächsten Art Mode gesendet", "TV connectée": "Fernseher verbunden",
  "Recherche de la TV sur le réseau…": "Fernseher wird im Netzwerk gesucht …", "TV injoignable (allumée ?)": "Fernseher nicht erreichbar (eingeschaltet?)",
  "La TV n’accepte des images qu’en mode Art. Rien à faire : dès qu’elle y repasse (par exemple quand tu l’éteins avec la télécommande), les images en attente partent toutes seules.":
    "Der Fernseher nimmt Bilder nur im Art Mode an. Du musst nichts tun: Sobald er wieder in den Art Mode wechselt (zum Beispiel wenn du ihn mit der Fernbedienung ausschaltest), werden die wartenden Bilder automatisch gesendet.",
  // Bandeau des images supprimées depuis la télécommande
  "Images supprimées depuis la télécommande": "Mit der Fernbedienung gelöschte Bilder",
  "Une image supprimée depuis la télécommande": "Ein Bild wurde mit der Fernbedienung gelöscht",
  "Effacer du Mac": "Vom Mac löschen", "Garder sur le Mac": "Auf dem Mac behalten",
  "Effacer l’image du Mac": "Bild vom Mac löschen", "Les garder sur le Mac": "Auf dem Mac behalten", "La garder sur le Mac": "Auf dem Mac behalten",
  "Elles ne sont plus sur la TV. Les effacer aussi de ce Mac ? Une image effacée ne peut pas être récupérée.":
    "Sie sind nicht mehr auf dem Fernseher. Auch von diesem Mac löschen? Ein gelöschtes Bild kann nicht wiederhergestellt werden.",
  "Elle n’est plus sur la TV. L’effacer aussi de ce Mac ? Une image effacée ne peut pas être récupérée.":
    "Es ist nicht mehr auf dem Fernseher. Auch von diesem Mac löschen? Ein gelöschtes Bild kann nicht wiederhergestellt werden.",
  // Collection
  "Rechercher dans ma collection (Monet, neige, Berlin…)": "In meiner Sammlung suchen (Monet, Schnee, Berlin …)",
  "Rechercher dans ma collection": "In meiner Sammlung suchen",
  "Sur la TV": "Auf dem Fernseher", "Aucun thème affiché.": "Kein Thema wird angezeigt.", "En attente": "Wartet",
  "Afficher sur la TV": "Auf dem Fernseher zeigen",
  "Vide pour l’instant : ajoute des images depuis l’onglet « Ajouter ».": "Noch leer: Füge Bilder über den Tab „Hinzufügen“ hinzu.",
  // Ajouter
  "Artistes, lieux, sujets… (en français ou en anglais)": "Künstler, Orte, Motive … (auf Deutsch oder Englisch)",
  "Rechercher des œuvres et des photos": "Kunstwerke und Fotos suchen", "Sources": "Quellen",
  "Tout": "Alle", "Musées": "Museen", "Photos": "Fotos", "Espace": "Weltraum", "Œuvres": "Kunstwerke",
  "Tes photos": "Deine Fotos", "Depuis la photothèque de ton téléphone": "Aus der Fotomediathek deines Handys",
  "Depuis ce Mac ou depuis ton iPhone": "Von diesem Mac oder deinem iPhone", "Choisir…": "Auswählen …",
  "Découvrir": "Entdecken", "Touche une sélection pour voir ses œuvres": "Tippe auf eine Galerie, um ihre Werke zu sehen",
  "Retour à Découvrir": "Zurück zu Entdecken", "‹ Découvrir": "‹ Entdecken",
  "Mes sélections": "Meine Galerien", "Peinture": "Malerei", "Sujets": "Motive", "Photographie": "Fotografie",
  "Nouvelle sélection": "Neue Galerie", "Modifier la sélection": "Galerie bearbeiten", "Réduire": "Weniger", "Tout afficher": "Alle anzeigen",
  "Touche + pour créer ta sélection à partir de mots-clés.": "Tippe auf +, um eine eigene Galerie aus Stichwörtern zu erstellen.",
  "Tout réafficher": "Alle wieder einblenden", "Modifier…": "Bearbeiten …", "Supprimer…": "Löschen …",
  "Déplacer vers la gauche": "Nach links bewegen", "Déplacer vers la droite": "Nach rechts bewegen",
  "Masquer cette sélection": "Diese Galerie ausblenden", "Sélection masquée": "Galerie ausgeblendet",
  "Toutes les sélections sont réaffichées": "Alle Galerien werden wieder angezeigt",
  "Sélection modifiée": "Galerie geändert", "Sélection créée dans « Mes sélections »": "Galerie unter „Meine Galerien“ erstellt",
  "Sélection supprimée": "Galerie gelöscht", "Supprimer la sélection": "Galerie löschen",
  "Elle disparaîtra de « Mes sélections ». Les œuvres déjà ajoutées restent dans ta collection.":
    "Sie verschwindet aus „Meine Galerien“. Bereits hinzugefügte Werke bleiben in deiner Sammlung.",
  "Ajouter dans…": "Hinzufügen zu …", "Ajouter dans": "Hinzufügen zu", "Ajouter…": "Hinzufügen …", "Nouveau dossier…": "Neuer Ordner …",
  "Recherche…": "Suche …", "Plus de résultats": "Weitere Ergebnisse", "portrait": "Hochformat", "basse déf.": "geringe Aufl.",
  "Résolution inférieure à la 4K : rendu un peu doux sur la TV": "Auflösung unter 4K: auf dem Fernseher etwas weich",
  "Aucun résultat. Essaie en anglais ou une autre source.": "Keine Ergebnisse. Versuche es auf Englisch oder mit einer anderen Quelle.",
  "Mots-clés": "Stichwörter", "Aperçu sur la TV": "Vorschau auf dem Fernseher", "Terminé": "Fertig", "Annuler": "Abbrechen",
  "Sans titre": "Ohne Titel", "format paysage": "Querformat", "format portrait : bandes sur les côtés": "Hochformat: Streifen an den Seiten",
  "qualité 4K": "4K-Qualität", "bonne définition": "gute Auflösung",
  "✓ Ajoutée": "✓ Hinzugefügt", "Dossier": "Ordner", "Déplacement…": "Wird verschoben …", "Ajout…": "Wird hinzugefügt …",
  "Ajoutée": "Hinzugefügt", "Réessayer": "Erneut versuchen", "Cette œuvre": "Dieses Werk",
  // Fiche image
  "Image": "Bild", "Dossier de l’image": "Ordner des Bildes", "Supprimer l’image": "Bild löschen",
  "Supprimer cette image ?": "Dieses Bild löschen?", "Supprimée": "Gelöscht", "Déplacer": "Verschieben", "Déplacée": "Verschoben",
  "Envoi à la TV…": "Wird an den Fernseher gesendet …", "Affichée sur la TV": "Auf dem Fernseher angezeigt",
  "Elle sera affichée sur la TV avec ce thème.": "Es wird mit diesem Thema auf dem Fernseher angezeigt.",
  "Ce thème est en réserve : elle sera retirée de la TV.": "Dieses Thema ist nur auf dem Mac: Das Bild wird vom Fernseher entfernt.",
  "Ce thème est en réserve : elle ne sera pas affichée sur la TV.": "Dieses Thema ist nur auf dem Mac: Das Bild wird nicht auf dem Fernseher angezeigt.",
  // Dossiers
  "Nouveau dossier": "Neuer Ordner", "Il sera affiché sur la TV.": "Er wird auf dem Fernseher angezeigt.", "Créer": "Erstellen", "Nom": "Name",
  "Nom du dossier": "Ordnername", "Ex. : Vacances 2026": "z. B. Urlaub 2026",
  // Synchronisation
  "Synchronisation lancée": "Synchronisierung gestartet", "Démarrage…": "Start …", "Lecture de la TV…": "Fernseher wird gelesen …",
  "Synchronisation terminée": "Synchronisierung abgeschlossen", "TV à jour": "Fernseher ist aktuell",
  "Fichiers effacés du Mac": "Dateien vom Mac gelöscht", "Images gardées": "Bilder behalten",
  "Envoi sur la TV…": "Wird auf den Fernseher gesendet …", "Retrait de la TV…": "Wird vom Fernseher entfernt …",
  "Saison changée, mise à jour de la TV…": "Jahreszeit geändert, Fernseher wird aktualisiert …",
  // Télécommande
  "Source (HDMI…)": "Quelle (HDMI …)", "Source": "Quelle", "Mode Art": "Art Mode", "Marche / arrêt": "Ein / Aus", "Marche ou arrêt": "Ein oder aus",
  "Mode de contrôle": "Steuerungsart", "Pavé": "Touchpad", "Flèches": "Pfeiltasten",
  "Pavé de la TV. Glisse pour déplacer le curseur, touche pour cliquer.": "Touchpad des Fernsehers. Wischen bewegt den Zeiger, Tippen klickt.",
  "Contrôler la TV": "Fernseher steuern",
  "Ta souris, ton trackpad et ton clavier pilotent directement la TV. Regarde simplement l’écran de la TV.":
    "Maus, Trackpad und Tastatur steuern direkt den Fernseher. Schau einfach auf den Bildschirm des Fernsehers.",
  "Raccourcis": "Kurzbefehle", "clic": "Klick", "cliquer": "klicken", "clic droit": "Rechtsklick", "Retour": "Zurück", "2 doigts": "2 Finger",
  "défiler": "scrollen", "taper": "tippen", "écrire,": "schreiben,", "valider": "bestätigen", "Accueil": "Home", "⌥Espace": "⌥Leertaste",
  "Lecture/Pause": "Wiedergabe/Pause", "Volume": "Lautstärke", "Muet": "Ton aus", "Échap": "esc", "reprendre la main": "Steuerung zurückholen",
  "Haut": "Oben", "Gauche": "Links", "Droite": "Rechts", "Bas": "Unten", "OK": "OK",
  "Lecture / Pause": "Wiedergabe / Pause", "Lecture ou pause": "Wiedergabe oder Pause",
  "Volume +": "Lauter", "Volume plus": "Lauter", "Volume −": "Leiser", "Volume moins": "Leiser", "VOL": "VOL",
  "Chaîne": "Sender", "Chaîne +": "Nächster Sender", "Chaîne suivante": "Nächster Sender", "Chaîne −": "Vorheriger Sender", "Chaîne précédente": "Vorheriger Sender", "CH": "CH",
  "Menu de la TV": "Menü des Fernsehers",
  "Taper sur la TV…": "Auf dem Fernseher tippen …", "Texte à envoyer à la TV": "Text für den Fernseher", "Envoyer et valider": "Senden und bestätigen",
  "Glisse pour déplacer le curseur · touche pour cliquer": "Wischen bewegt den Zeiger · Tippen klickt",
  "Clique ici (ou ⌘⇧T) : ta souris et ton clavier pilotent la TV, sans avoir à rester dans ce cadre · Échap pour reprendre la main":
    "Hier klicken (oder ⌘⇧T): Maus und Tastatur steuern den Fernseher, auch außerhalb dieses Felds · esc holt die Steuerung zurück",
  "Survole pour déplacer le curseur · clique pour capturer la souris (Échap pour la rendre)":
    "Darüberfahren bewegt den Zeiger · Klicken übernimmt die Maus (esc gibt sie zurück)",
  "Souris capturée : elle pilote la TV · clic = clic sur la TV · Échap pour la rendre":
    "Maus übernommen: Sie steuert den Fernseher · Klick = Klick auf dem Fernseher · esc gibt sie zurück",
  "Contrôle de la TV": "Fernsehersteuerung", "Ta souris et ton clavier pilotent la TV": "Maus und Tastatur steuern den Fernseher",
  "Bouge, clique, fais défiler à deux doigts · clic droit = Retour · tape pour écrire, ↵ pour valider":
    "Bewegen, klicken, mit zwei Fingern scrollen · Rechtsklick = Zurück · tippen zum Schreiben, ↵ zum Bestätigen",
  "Accueil ·": "Home ·", "Lecture/Pause ·": "Wiedergabe/Pause ·", "Volume ·": "Lautstärke ·", "Muet ·": "Ton aus ·",
  "pour reprendre la main": "holt die Steuerung zurück",
  "Contrôle de la TV activé : ta souris et ton clavier pilotent la TV. Échap pour reprendre la main.":
    "Fernsehersteuerung aktiv: Maus und Tastatur steuern den Fernseher. esc holt die Steuerung zurück.",
  "Tu as repris la main sur le Mac.": "Du steuerst wieder den Mac.",
  "La TV attend du texte : ce que tu tapes s’affiche en direct, ↵ pour valider": "Der Fernseher wartet auf Text: Was du tippst, erscheint sofort, ↵ zum Bestätigen",
  "Envoyé. S’il n’apparaît pas, sélectionne d’abord un champ sur la TV": "Gesendet. Falls nichts erscheint, wähle zuerst ein Eingabefeld auf dem Fernseher",
  "Validé sur la TV": "Auf dem Fernseher bestätigt",
  "Enregistré : appliqué au prochain passage en mode Art": "Gespeichert: wird beim nächsten Art Mode übernommen", "Diaporama réglé": "Diashow eingestellt",
  // Réglages
  "Optimiser ma Frame": "Meine FRAME optimieren", "Optimiser l’image et le son": "Bild und Ton optimieren",
  "Un guide pas à pas pour régler la TV au mieux. À faire une fois, puis après une grosse mise à jour de la TV.":
    "Eine Schritt-für-Schritt-Anleitung für die besten Einstellungen. Einmal durchgehen und dann wieder nach einem großen Update des Fernsehers.",
  "Lecture des réglages de la TV…": "Einstellungen des Fernsehers werden gelesen …",
  "Ces réglages sont enregistrés directement sur ta TV. Garde le capteur de luminosité activé pour un rendu « vrai tableau ».":
    "Diese Einstellungen werden direkt auf deinem Fernseher gespeichert. Lass den Helligkeitssensor an, damit das Bild wie ein echtes Gemälde wirkt.",
  "La TV n’a pas renvoyé ses réglages (est-elle allumée ?)": "Der Fernseher hat seine Einstellungen nicht gesendet (ist er eingeschaltet?)",
  "Luminosité": "Helligkeit", "Ton de couleur": "Farbton", "Capteur de luminosité": "Helligkeitssensor",
  "Mise en veille après": "Ruhezustand nach", "Détecteur de présence": "Bewegungssensor",
  "Froid": "Kalt", "Chaud": "Warm", "Faible": "Niedrig", "Moyenne": "Mittel", "Élevée": "Hoch", "Neutre": "Neutral",
  "Jamais": "Nie", "1 heure": "1 Stunde", "2 heures": "2 Stunden", "4 heures": "4 Stunden",
  "Appliquer les réglages conseillés": "Empfohlene Einstellungen übernehmen", "Appliquer les réglages conseillés ?": "Empfohlene Einstellungen übernehmen?",
  "Appliquer": "Übernehmen", "Réglages conseillés appliqués": "Empfohlene Einstellungen übernommen", "Réglage envoyé à la TV": "Einstellung an den Fernseher gesendet",
  "Diaporama": "Diashow", "Changer d’image": "Bild wechseln", "Toutes les 15 min": "Alle 15 Min.", "Toutes les heures": "Jede Stunde",
  "Toutes les 3 heures": "Alle 3 Stunden", "Toutes les 12 heures": "Alle 12 Stunden", "Tous les jours": "Jeden Tag",
  "Vitesse du curseur": "Zeigergeschwindigkeit", "Lent": "Langsam", "Rapide": "Schnell", "Normale": "Normal",
  "iPhone et autres appareils": "iPhone und andere Geräte", "Adresse": "Adresse", "Code d’accès": "Zugangscode", "Générer un nouveau code": "Neuen Code erstellen",
  "Ouvre l’adresse dans Safari sur ton iPhone (même Wi-Fi), saisis le code, puis Partager → « Sur l’écran d’accueil ». Un nouveau code déconnecte les appareils déjà connectés.":
    "Öffne die Adresse in Safari auf deinem iPhone (gleiches WLAN), gib den Code ein und tippe dann auf Teilen → „Zum Home-Bildschirm“. Ein neuer Code trennt alle bereits verbundenen Geräte.",
  "Créer un nouveau code d’accès ?": "Neuen Zugangscode erstellen?", "Créer un nouveau code": "Neuen Code erstellen",
  "L’ancien code ne fonctionnera plus : ton iPhone et tes autres appareils devront saisir le nouveau.":
    "Der alte Code funktioniert dann nicht mehr: Dein iPhone und deine anderen Geräte müssen den neuen eingeben.",
  "Nouveau code créé": "Neuer Code erstellt",
  "Avancé": "Erweitert", "Améliorer toute la collection": "Ganze Sammlung verbessern", "Améliorer les images ajoutées depuis l’appli": "In der App hinzugefügte Bilder verbessern",
  "Améliorer toute la collection ?": "Ganze Sammlung verbessern?", "Améliorer": "Verbessern",
  "Chaque image est recherchée à sa source, retéléchargée puis remplacée sur la TV. Compte une vingtaine de minutes ; l’appli reste utilisable.":
    "Jedes Bild wird an seiner Quelle gesucht, neu geladen und auf dem Fernseher ersetzt. Das dauert etwa zwanzig Minuten; die App bleibt nutzbar.",
  "Retraiter les images ajoutées ?": "Hinzugefügte Bilder neu verarbeiten?", "Retraiter": "Neu verarbeiten",
  "Les images ajoutées depuis l’appli sont retéléchargées, puis remplacées sur la TV par leur nouvelle version.":
    "Die in der App hinzugefügten Bilder werden neu geladen und auf dem Fernseher durch die neue Version ersetzt.",
  "Retrouve chaque image à sa source, la retélécharge dans la meilleure qualité disponible, corrige ses couleurs (sRGB) et la remplace sur la TV. Les images introuvables avec certitude restent telles quelles.":
    "Sucht jedes Bild an seiner Quelle, lädt es in der besten verfügbaren Qualität neu, korrigiert die Farben (sRGB) und ersetzt es auf dem Fernseher. Bilder, die nicht sicher gefunden werden, bleiben unverändert.",
  "Images améliorées et remplacées sur la TV": "Bilder verbessert und auf dem Fernseher ersetzt",
  "Langue": "Sprache", "Langue de l’appli": "Sprache der App",
  "Mises à jour": "Aktualisierungen", "Version": "Version", "Dernière mise à jour": "Letzte Aktualisierung",
  "Les nouveautés s’installent toutes seules. Tes images, tes réglages et ta TV ne sont jamais touchés.": "Neuerungen werden automatisch installiert. Deine Bilder, Einstellungen und dein Fernseher bleiben unangetastet.",
  // Fiche « Nouvelle sélection »
  "Enregistrer": "Sichern", "Ex. : Ma Bretagne, Chats, Peintres nordiques": "z. B. Ostsee, Katzen, Nordische Maler",
  "Mots-clés, séparés par des virgules (artistes, lieux, sujets)": "Stichwörter, durch Kommas getrennt (Künstler, Orte, Motive)",
  "Ex. : Brittany, Paul Gauguin Pont-Aven, Breton coast, lighthouse": "z. B. Baltic Sea, Caspar David Friedrich, Rügen, lighthouse",
  "Description (facultatif)": "Beschreibung (optional)", "Une phrase pour te rappeler l’esprit de la sélection": "Ein Satz, der beschreibt, worum es in der Galerie geht",
  "Il faut un nom et au moins un mot-clé": "Bitte gib einen Namen und mindestens ein Stichwort ein",
  // Photos
  "1 photo": "1 Foto", "Mes photos": "Meine Fotos", "Mes photos (nouveau)": "Meine Fotos (neu)", "Aucune photo reconnue": "Kein Foto erkannt",
  "Afficher tout de suite sur la TV": "Sofort auf dem Fernseher zeigen",
  "Elles seront mises au format de la TV, sans recadrage, avec des bandes sombres si besoin.": "Sie werden ohne Zuschneiden an das Format des Fernsehers angepasst, bei Bedarf mit dunklen Streifen.",
  "Elle sera mise au format de la TV, sans recadrage, avec des bandes sombres si besoin.": "Es wird ohne Zuschneiden an das Format des Fernsehers angepasst, bei Bedarf mit dunklen Streifen.",
  "Envoi de la photo… Garde cette page ouverte.": "Foto wird gesendet … Lass diese Seite geöffnet.",
  "Affichage sur la TV…": "Wird auf dem Fernseher angezeigt …", "Donne un nom au nouveau dossier": "Gib dem neuen Ordner einen Namen",
  "Cette photo est déjà dans ta collection": "Dieses Foto ist schon in deiner Sammlung", "1 déjà dans ta collection": "1 schon in deiner Sammlung",
  "La photo n’a pas pu être ajoutée": "Das Foto konnte nicht hinzugefügt werden", "1 n’a pas pu être ajoutée": "1 konnte nicht hinzugefügt werden",
  "affichée sur la TV": "auf dem Fernseher angezeigt", "la TV ne répond pas, elle l’affichera à la prochaine mise à jour": "der Fernseher antwortet nicht, es wird beim nächsten Abgleich angezeigt",
  // Assistant « Optimiser ma Frame »
  "Fermer": "Schließen", "Ouvrir les réglages sur la TV": "Einstellungen auf dem Fernseher öffnen", "Tout décocher": "Alle Häkchen entfernen",
  "Fais chaque réglage avec la télécommande, puis touche le rond pour le cocher. Les noms sont ceux des menus anglais de la TV.":
    "Nimm jede Einstellung mit der Fernbedienung vor und tippe dann auf den Kreis, um sie abzuhaken. Die Namen entsprechen den deutschen Menüs des Fernsehers.",
  "Après une mise à jour de la TV, un menu peut changer de place : cherche son nom avec la loupe des réglages de la TV.":
    "Nach einem Update kann ein Menü an einer anderen Stelle stehen: Suche seinen Namen mit der Lupe in den Einstellungen des Fernsehers.",
  "Tout décocher ?": "Alle Häkchen entfernen?", "Décocher": "Entfernen", "Les réglages de la TV ne changent pas, seules les coches sont effacées.":
    "Die Einstellungen des Fernsehers bleiben unverändert, nur die Häkchen werden entfernt.",
  "Tout est fait ✓": "Alles erledigt ✓", "Son": "Ton", "Général": "Allgemein", "Image ·": "Bild ·", "Son ·": "Ton ·", "Général ·": "Allgemein ·", "Mode Art ·": "Art Mode ·",
  "Settings > All Settings > Picture": "Einstellungen > Alle Einstellungen > Bild", "Settings > All Settings > Sound": "Einstellungen > Alle Einstellungen > Ton",
  "Settings > All Settings": "Einstellungen > Alle Einstellungen",
  "Picture Mode": "Bildmodus", "Filmmaker": "Filmmaker-Modus", "Picture > Picture Mode": "Bild > Bildmodus",
  "Couleurs fidèles, sans effet « soap opera ». « Standard » si la pièce est très lumineuse.": "Natürliche Farben ohne „Soap-Opera-Effekt“. „Standard“, wenn der Raum sehr hell ist.",
  "Picture Clarity": "Bildklarheit", "Custom, tout à 0": "Benutzerdefiniert, alles auf 0", "Picture > Expert Settings > Picture Clarity Settings": "Bild > Experteneinstellungen > Einstellungen für Bildklarheit",
  "Judder Reduction 0, LED Clear Motion Off, Noise Reduction Off : mouvement naturel, image nette.": "Judder-Reduzierung 0, LED Clear Motion Aus, Rauschunterdrückung Aus: natürliche Bewegung, scharfes Bild.",
  "Contrast Enhancer": "Kontrastverbesserung", "Low": "Niedrig", "Picture > Expert Settings": "Bild > Experteneinstellungen",
  "Évite les visages trop contrastés.": "Verhindert zu kontrastreiche Gesichter.",
  "Colour Tone": "Farbton", "Warm 1": "Warm 1", "Blancs naturels, souvent déjà réglé par Filmmaker.": "Natürliches Weiß, im Filmmaker-Modus meist schon eingestellt.",
  "Brightness Optimization": "Helligkeitsoptimierung", "On": "Ein", "Off": "Aus", "General & Privacy > Power and Energy Saving": "Allgemein und Datenschutz > Energie und Energiesparen",
  "L'écran suit la lumière de la pièce.": "Der Bildschirm passt sich dem Raumlicht an.",
  "Sound Output": "Tonausgabe", "Receiver (Optical)": "Receiver (Optisch)", "Sound > Sound Output": "Ton > Tonausgabe",
  "Si une barre de son est branchée en optique. Sinon, laisse TV Speaker.": "Wenn eine Soundbar optisch angeschlossen ist. Sonst „TV-Lautsprecher“ lassen.",
  "Digital Output Audio Format": "Digitales Audioausgabeformat", "PCM": "PCM", "Sound > Expert Settings": "Ton > Experteneinstellungen",
  "Garde le réglage du volume depuis la TV.": "So bleibt die Lautstärke über den Fernseher regelbar.",
  "Simultaneous Optical Output": "Gleichzeitige optische Ausgabe", "Sinon le son repasse aussi par la TV.": "Sonst kommt der Ton zusätzlich aus dem Fernseher.",
  "Le son sort par": "Der Ton kommt aus", "Haut-parleurs de la TV": "Lautsprecher des Fernsehers", "Barre de son en optique": "Soundbar (optisch)",
  "TV Speaker": "TV-Lautsprecher", "Le son sort des haut-parleurs de la TV.": "Der Ton kommt aus den Lautsprechern des Fernsehers.",
  "Sound Mode": "Tonmodus", "Standard": "Standard", "Sound > Sound Mode": "Ton > Tonmodus",
  "Son équilibré. Essaie « Amplify » si les voix sont difficiles à comprendre.": "Ausgewogener Klang. Probiere „Verstärken“, wenn Stimmen schwer zu verstehen sind.",
  "Auto Volume": "Auto-Lautstärke", "Normal": "Normal", "Évite les sauts de volume entre chaînes et publicités.": "Verhindert Lautstärkesprünge zwischen Sendern und Werbung.",
  "Une seule télécommande": "Nur eine Fernbedienung", "Universal Remote": "Universalfernbedienung",
  "Home > Connected Devices > Universal Remote Setup > Start > Home Theater": "Home > Verbundene Geräte > Einrichtung der Universalfernbedienung > Start > Heimkino",
  "Choisis la marque de la barre de son : la télécommande Samsung et l'appli règlent alors son volume.": "Wähle die Marke der Soundbar: Dann regeln die Samsung-Fernbedienung und die App ihre Lautstärke.",
  "Réglages du tableau": "Bildeinstellungen im Art Mode", "En un geste": "Mit einem Tipp",
  "La TV doit être en mode Art (appui court sur Power).": "Der Fernseher muss im Art Mode sein (Ein/Aus-Taste kurz drücken).",
  "Luminosité suivie par le capteur, ton un peu chaud, veille après 30 min dans une pièce vide.": "Helligkeit folgt dem Sensor, etwas wärmerer Farbton, Ruhezustand nach 30 Min. in einem leeren Raum.",
  "Night Mode": "Nachtmodus", "Home > Art > roue dentée": "Home > Art > Zahnrad", "L'écran s'éteint dans le noir complet.": "Der Bildschirm schaltet sich bei völliger Dunkelheit aus.",
  "Auto Update": "Automatisches Update", "Support > Software Update": "Support > Software-Update",
  "Corrections installées pendant que la TV est éteinte.": "Updates werden installiert, während der Fernseher aus ist.",
  // Bienvenue
  "Bienvenue dans Ma Frame": "Willkommen bei Ma Frame", "Ta galerie d’art pour The Frame, en quatre idées.": "Deine Kunstgalerie für The Frame, in vier Punkten.",
  "Ta collection, rangée par thèmes": "Deine Sammlung, nach Themen geordnet",
  "Les thèmes « Sur la TV » passent en diaporama. Ceux « En réserve » restent sur ton Mac. Un interrupteur suffit pour basculer.":
    "Themen unter „Auf dem Fernseher“ laufen als Diashow. Themen unter „Nur auf dem Mac“ bleiben auf deinem Mac. Ein Schalter genügt zum Wechseln.",
  "Tout se synchronise seul": "Alles synchronisiert sich selbst",
  "Ajouts, thèmes activés, saisons qui changent : la TV se met à jour toute seule. Une image supprimée avec la télécommande disparaît aussi du Mac.":
    "Neue Bilder, aktivierte Themen, wechselnde Jahreszeiten: Der Fernseher aktualisiert sich selbst. Ein mit der Fernbedienung gelöschtes Bild verschwindet auch vom Mac.",
  "Découvre et ajoute": "Entdecken und hinzufügen",
  "Dans Ajouter, cherche en français ou explore les sélections, regarde les œuvres en grand puis touche « + ». Les sélections que tu crées vont dans « Mes sélections ».":
    "Suche unter „Hinzufügen“ auf Deutsch oder stöbere in den Galerien, sieh dir die Werke groß an und tippe auf „+“. Eigene Galerien landen unter „Meine Galerien“.",
  "Pilote la TV, même depuis l’iPhone": "Steuere den Fernseher, auch vom iPhone",
  "Dans Télécommande, pilote la TV avec ta souris et ton clavier (⌘⇧T). Les réglages donnent l’adresse et le code pour ton téléphone.":
    "Unter „Fernbedienung“ steuerst du den Fernseher mit Maus und Tastatur (⌘⇧T). In den Einstellungen findest du Adresse und Code für dein Handy.",
  "Commencer": "Los geht’s",
  // Arrêt
  "Arrêter Ma Frame ?": "Ma Frame beenden?", "Arrêter": "Beenden",
  "La TV et le diaporama continuent de tourner. Pour rouvrir l’appli, relance « Ma Frame ».": "Fernseher und Diashow laufen weiter. Starte „Ma Frame“ erneut, um die App wieder zu öffnen.",
  "Appli arrêtée. Relance « Ma Frame » pour la rouvrir.": "App beendet. Starte „Ma Frame“ erneut, um sie wieder zu öffnen.",
  // Thèmes et saisons (noms donnés par le moteur)
  "Photos incroyables": "Unglaubliche Fotos", "Chefs-d'œuvre": "Meisterwerke", "Estampes japonaises": "Japanische Holzschnitte",
  "Impressionnistes": "Impressionisten", "Printemps": "Frühling", "Été": "Sommer", "Automne": "Herbst", "Hiver": "Winter", "Noël": "Weihnachten",
  "Nature": "Natur", "Black white": "Schwarz-Weiß", "saison en cours": "aktuelle Jahreszeit",
  // Messages du moteur
  "code d’accès requis": "Zugangscode erforderlich", "commande refusée": "Befehl abgelehnt", "Code incorrect": "Falscher Code",
  "photo trop lourde (60 Mo au plus)": "Foto zu groß (höchstens 60 MB)", "uniquement depuis le Mac": "nur vom Mac aus möglich",
  "choisis un autre nom de dossier": "Wähle einen anderen Ordnernamen", "chemin refusé": "Pfad abgelehnt", "réglage inconnu": "Unbekannte Einstellung",
  "TV : accès refusé": "Fernseher: Zugriff verweigert", "source indisponible": "Quelle nicht verfügbar",
  "image indisponible sur le serveur d'origine": "Bild auf dem Ursprungsserver nicht verfügbar", "photo vide": "Leeres Foto", "thème inconnu": "Unbekanntes Thema",
  "format de photo non reconnu": "Fotoformat nicht erkannt", "hôte refusé": "Server abgelehnt", "image indisponible": "Bild nicht verfügbar",
  "pas de réponse de la TV": "Keine Antwort vom Fernseher",
  "La TV démarre encore ou vient de s’éteindre. Réessaie dans une minute.": "Der Fernseher startet noch oder wurde gerade ausgeschaltet. Versuche es in einer Minute noch einmal.",
  "La TV n’accepte des images qu’en mode Art : elles partiront toutes seules dès qu’elle y repassera.": "Der Fernseher nimmt Bilder nur im Art Mode an: Sie werden automatisch gesendet, sobald er wieder im Art Mode ist.",
  "La TV est introuvable : est-elle allumée et sur le même Wi-Fi ?": "Der Fernseher wurde nicht gefunden: Ist er eingeschaltet und im selben WLAN?",
  "La TV ne répond pas · redémarre-la": "Der Fernseher antwortet nicht · starte ihn neu",
  // Premier lancement : autorisation et collection de départ
  "Sur la TV, choisis « Autoriser »": "Wähle auf dem Fernseher „Zulassen“", "Collection de départ": "Startsammlung wird geladen",
  "Français": "Français", "Deutsch": "Deutsch"
};

// ---------- Sélections de Découvrir : nom, description, artistes ----------
Object.assign(DE, {
  "Impressionnisme": "Impressionismus", "La lumière et l’instant, par petites touches rapides. Fin du XIXe siècle, en France.": "Licht und Augenblick in schnellen, kleinen Pinselstrichen. Frankreich, Ende des 19. Jahrhunderts.",
  "Post-impressionnisme": "Postimpressionismus", "Des couleurs franches et des formes plus expressives, juste après l’impressionnisme.": "Kräftige Farben und ausdrucksstarke Formen, direkt nach dem Impressionismus.",
  "Pointillisme": "Pointillismus", "Des milliers de petits points de couleur pure que l’œil mélange à distance.": "Tausende kleine Punkte reiner Farbe, die das Auge aus der Ferne vermischt.",
  "Gravures sur bois de l’époque d’Edo : lignes nettes, aplats de couleur, Mont Fuji et vagues.": "Holzschnitte der Edo-Zeit: klare Linien, flächige Farben, Fuji und Wellen.",
  "Intérieurs intimistes": "Stille Interieurs", "Des pièces calmes baignées de lumière douce, parfait pour une ambiance cosy.": "Ruhige Räume in sanftem Licht, perfekt für eine gemütliche Stimmung.",
  "Siècle d’or hollandais": "Niederländisches Goldenes Zeitalter", "Scènes du quotidien, paysages et natures mortes d’une précision lumineuse, au XVIIe siècle.": "Alltagsszenen, Landschaften und Stillleben von leuchtender Präzision, 17. Jahrhundert.",
  "Romantisme": "Romantik", "Nature grandiose, ciels tourmentés et émotion, au début du XIXe siècle.": "Gewaltige Natur, stürmische Himmel und Gefühl, Anfang des 19. Jahrhunderts.",
  "Réalisme": "Realismus", "La vie paysanne et les paysages tels qu’ils sont, sans idéalisation.": "Bäuerliches Leben und Landschaften, wie sie sind, ohne Idealisierung.",
  "Hudson River School": "Hudson River School", "Les grands paysages américains, lumineux et spectaculaires.": "Die großen amerikanischen Landschaften, leuchtend und spektakulär.",
  "Marines": "Seestücke", "La mer sous toutes ses humeurs : vagues, tempêtes, ports et bateaux.": "Das Meer in all seinen Stimmungen: Wellen, Stürme, Häfen und Schiffe.",
  "Art nouveau": "Jugendstil", "Courbes, motifs floraux et figures élégantes, vers 1900.": "Schwungvolle Linien, florale Motive und elegante Figuren, um 1900.",
  "Symbolisme": "Symbolismus", "Rêves, mythes et atmosphères mystérieuses.": "Träume, Mythen und geheimnisvolle Stimmungen.",
  "Préraphaélites": "Präraffaeliten", "Légendes et poésie, couleurs vives et détails minutieux, en Angleterre.": "Legenden und Poesie, leuchtende Farben und feine Details, aus England.",
  "Expressionnisme": "Expressionismus", "Couleurs intenses et formes déformées pour exprimer les émotions.": "Intensive Farben und verzerrte Formen, die Gefühle ausdrücken.",
  "Renaissance": "Renaissance", "Harmonie, perspective et beauté classique, en Italie aux XVe–XVIe siècles.": "Harmonie, Perspektive und klassische Schönheit, Italien im 15. und 16. Jahrhundert.",
  "Paysages chinois": "Chinesische Landschaften", "Montagnes dans la brume et rivières à l’encre, tout en poésie.": "Berge im Nebel und Flüsse in Tusche, voller Poesie.",
  "Botticelli, Léonard de Vinci, Raphaël, Titien": "Botticelli, Leonardo da Vinci, Raffael, Tizian",
  "Fleurs": "Blumen", "Bouquets, champs fleuris et natures mortes florales.": "Sträuße, Blumenwiesen und Blumenstillleben.",
  "Jardins": "Gärten", "Allées fleuries, bassins et jardins secrets.": "Blühende Wege, Teiche und verborgene Gärten.",
  "Clairs de lune": "Mondnächte", "Nuits bleutées, reflets argentés et lumière lunaire.": "Blaue Nächte, silberne Spiegelungen und Mondlicht.",
  "Neige et hiver": "Schnee und Winter", "Villages sous la neige, patineurs et silences blancs.": "Verschneite Dörfer, Schlittschuhläufer und weiße Stille.",
  "Mer et plages": "Meer und Strände", "Bord de mer, baigneurs, falaises et horizons.": "Küste, Badende, Klippen und Horizonte.",
  "Ports et bateaux": "Häfen und Schiffe", "Voiliers, quais animés et lumières de port.": "Segelboote, belebte Kais und Hafenlichter.",
  "Venise": "Venedig", "Canaux, gondoles et palais dans la lumière dorée.": "Kanäle, Gondeln und Paläste im goldenen Licht.",
  "Paris d’autrefois": "Das alte Paris", "Boulevards, cafés et ponts de la Belle Époque.": "Boulevards, Cafés und Brücken der Belle Époque.",
  "Montagnes": "Berge", "Sommets, vallées alpines et grands espaces.": "Gipfel, Alpentäler und weite Landschaften.",
  "Animaux": "Tiere", "Chevaux, chats, oiseaux et animaux sauvages en peinture.": "Pferde, Katzen, Vögel und Wildtiere in der Malerei.",
  "Oiseaux": "Vögel", "Planches naturalistes et oiseaux en estampe.": "Naturkundliche Tafeln und Vögel im Holzschnitt.",
  "Botanique": "Botanik", "Planches de fleurs et de plantes d’une précision scientifique.": "Blumen- und Pflanzentafeln von wissenschaftlicher Genauigkeit.",
  "Natures mortes": "Stillleben", "Fruits, vases et objets du quotidien dans une lumière choisie.": "Früchte, Vasen und Alltagsgegenstände in gezieltem Licht.",
  "Scènes de vie": "Alltagsszenen", "Cafés, marchés, fêtes et instants du quotidien.": "Cafés, Märkte, Feste und Momente des Alltags.",
  "Danse et musique": "Tanz und Musik", "Danseuses, concerts et salles de spectacle.": "Tänzerinnen, Konzerte und Theatersäle.",
  "Affiches Belle Époque": "Plakate der Belle Époque", "Affiches illustrées et graphiques de 1900.": "Illustrierte Plakate und Grafik um 1900.",
  "Cartes anciennes": "Alte Landkarten", "Mappemondes, cartes marines et atlas illustrés.": "Weltkarten, Seekarten und illustrierte Atlanten.",
  "Cartes du ciel": "Himmelskarten", "Constellations et atlas célestes anciens.": "Sternbilder und alte Himmelsatlanten.",
  "Sciences et nature": "Wissenschaft und Natur", "Planches anciennes d’animaux marins, coquillages et minéraux.": "Alte Tafeln mit Meerestieren, Muscheln und Mineralien.",
  "Égypte et Orient": "Ägypten und Orient", "Temples, déserts et caravanes vus par les peintres voyageurs.": "Tempel, Wüsten und Karawanen, gesehen von reisenden Malern.",
  "Paysages grandioses": "Großartige Landschaften", "Montagnes, glaciers et parcs naturels, photographiés en très haute qualité.": "Berge, Gletscher und Nationalparks in sehr hoher Qualität fotografiert.",
  "Photos remarquables": "Ausgezeichnete Fotos",
  "Astrophotographie": "Astrofotografie", "Galaxies, nébuleuses et Voie lactée, par les télescopes Hubble et James Webb.": "Galaxien, Nebel und Milchstraße, von den Teleskopen Hubble und James Webb.",
  "Aurores et nuits": "Polarlichter und Nächte", "Aurores boréales et ciels étoilés.": "Nordlichter und Sternenhimmel.",
  "Noir et blanc": "Schwarz-Weiß", "L’élégance du monochrome : contrastes, brume, architecture.": "Die Eleganz des Monochromen: Kontraste, Nebel, Architektur.",
  "Photos anciennes": "Alte Fotografien", "Premières photographies et autochromes en couleur du début du XXe siècle.": "Erste Fotografien und farbige Autochrome vom Anfang des 20. Jahrhunderts.",
  "Vues aériennes": "Luftaufnahmen", "La Terre vue d’en haut : motifs, côtes et déserts depuis l’espace.": "Die Erde von oben: Muster, Küsten und Wüsten aus dem All.",
  "NASA, photos remarquables": "NASA, ausgezeichnete Fotos",
  "Nature et animaux": "Natur und Tiere", "Faune sauvage, oiseaux et forêts.": "Wildtiere, Vögel und Wälder.",
  "Villes": "Städte", "Skylines, rues et architecture.": "Skylines, Straßen und Architektur."
});

// ---------- Textes avec des nombres ou des noms ----------
const pl = (n, un, plus) => (+n === 1 ? un : plus);
const g = s => tr(s);                                       // nom de thème ou de dossier, traduit s'il est connu
const MOTIFS = [
  [/^(\d+) images · (\d+) sur la TV$/, (m, a, b) => `${a} ${pl(a, "Bild", "Bilder")} · ${b} auf dem Fernseher`],
  [/^(\d+) images · (\d+) en attente$/, (m, a, b) => `${a} ${pl(a, "Bild", "Bilder")} · ${b} ${pl(b, "wartet", "warten")}`],
  [/^(\d+) images · pas affichées sur la TV$/, (m, a) => `${a} ${pl(a, "Bild", "Bilder")} · nicht auf dem Fernseher`],
  [/^(\d+) en attente$/, (m, a) => `${a} ${pl(a, "wartet", "warten")}`],
  [/^(\d+) images$/, (m, a) => `${a} ${pl(a, "Bild", "Bilder")}`],
  [/^(\d+) résultats?$/, (m, a) => `${a} ${pl(a, "Treffer", "Treffer")}`],
  [/^› En réserve · (\d+) thèmes?$/, (m, a) => `› Nur auf dem Mac · ${a} ${pl(a, "Thema", "Themen")}`],
  [/^En réserve · (\d+) thèmes?$/, (m, a) => `Nur auf dem Mac · ${a} ${pl(a, "Thema", "Themen")}`],
  [/^Afficher (.+) sur la TV$/, (m, a) => `${g(a)} auf dem Fernseher zeigen`],
  [/^Automatique \((.+)\)$/, (m, a) => `Automatisch (${a.split(" + ").map(g).join(" + ")})`],
  [/^(.+) · sur la TV$/, (m, a) => `${g(a)} · auf dem Fernseher`],
  [/^(.+) · en attente d’envoi$/, (m, a) => `${g(a)} · wartet auf Senden`],
  [/^(.+) · en réserve$/, (m, a) => `${g(a)} · nur auf dem Mac`],
  [/^(.+) · suggéré$/, (m, a) => `${g(a)} · vorgeschlagen`],
  [/^(.+) · dernier utilisé$/, (m, a) => `${g(a)} · zuletzt verwendet`],
  [/^(\d+) images supprimées depuis la télécommande$/, (m, a) => `${a} Bilder wurden mit der Fernbedienung gelöscht`],
  [/^Effacer les (\d+) images du Mac$/, (m, a) => `${a} Bilder vom Mac löschen`],
  [/^Elles ne sont plus sur la TV\. Les effacer aussi de ce Mac \? Une image effacée ne peut pas être récupérée\.$/, () => DE["Elles ne sont plus sur la TV. Les effacer aussi de ce Mac ? Une image effacée ne peut pas être récupérée."]],
  [/^Dossier « (.+) » créé$/, (m, a) => `Ordner „${a}“ erstellt`],
  [/^Dossier non créé : (.+)$/, (m, a) => `Ordner nicht erstellt: ${tr(a)}`],
  [/^Déplacée dans « (.+) »$/, (m, a) => `Verschoben nach „${g(a)}“`],
  [/^Déplacer vers « (.+) » \?$/, (m, a) => `Nach „${g(a)}“ verschieben?`],
  [/^« (.+) » quittera le thème « (.+) »\. (.+)$/, (m, a, b, c) => `„${tr(a)}“ verlässt das Thema „${g(b)}“. ${tr(c)}`],
  [/^« (.+) » sera retirée de la TV et effacée de ce Mac\. Tu ne pourras pas annuler\.$/, (m, a) => `„${tr(a)}“ wird vom Fernseher entfernt und von diesem Mac gelöscht. Das kann nicht rückgängig gemacht werden.`],
  [/^« (.+) » sera effacée de ce Mac\. Tu ne pourras pas annuler\.$/, (m, a) => `„${tr(a)}“ wird von diesem Mac gelöscht. Das kann nicht rückgängig gemacht werden.`],
  [/^Supprimer la sélection « (.*) » \?$/, (m, a) => `Galerie „${a}“ löschen?`],
  [/^Ajoutée dans « (.+) »$/, (m, a) => `Zu „${g(a)}“ hinzugefügt`],
  [/^Ajoutée dans (.+)$/, (m, a) => `Zu ${g(a)} hinzugefügt`],
  [/^Déjà dans « (.+) »$/, (m, a) => `Schon in „${g(a)}“`],
  [/^Déjà dans (.+)$/, (m, a) => `Schon in ${g(a)}`],
  [/^✓ (.+)$/, (m, a) => `✓ ${g(a)}`],
  [/^Aperçu : (.+)$/, (m, a) => `Vorschau: ${a}`],
  [/^Ajouter (.+) dans un thème$/, (m, a) => `${a} zu einem Thema hinzufügen`],
  [/^(\d+) œuvres et photos pour « (.*) »$/, (m, a, b) => `${a} Werke und Fotos für „${tr(b)}“`],
  [/^(\d+) correspondances? pour « (.*) »(, puis des résultats approchants)?$/, (m, a, b, c) => `${a} ${pl(a, "Treffer", "Treffer")} für „${b}“${c ? ", danach ähnliche Ergebnisse" : ""}`],
  [/^Aucune œuvre ne correspond exactement à « (.*) » dans les musées et banques d’images \(œuvres anciennes et libres de droits\)\. Résultats approchants :$/,
    (m, a) => `Kein Werk passt genau zu „${a}“ in den Museen und Bilddatenbanken (alte, gemeinfreie Werke). Ähnliche Ergebnisse:`],
  [/^Erreur : (.*)$/, (m, a) => `Fehler: ${tr(a)}`],
  [/^TV : (.*)$/, (m, a) => `Fernseher: ${tr(a)}`],
  [/^Appli injoignable : (.*)$/, (m, a) => `App nicht erreichbar: ${tr(a)}`],
  [/^Réglages indisponibles : (.*)$/, (m, a) => `Einstellungen nicht verfügbar: ${tr(a)}`],
  [/^(.+) \((\d+)\/(\d+)\)$/, (m, a, b, c) => `${tr(a)} (${b}/${c})`],
  [/^Retrait de (\d+) image\(s\) des thèmes désactivés…$/, (m, a) => `${a} ${pl(a, "Bild", "Bilder")} deaktivierter Themen ${pl(a, "wird", "werden")} entfernt …`],
  [/^Envoi : (.+)$/, (m, a) => `Senden: ${nomImage(a)}`],
  [/^Échec pour (.+?) : (.+)$/, (m, a, b) => `Fehler bei ${nomImage(a)}: ${tr(b)}`],
  [/^Trop d’essais\. Réessaie dans (\d+) s\.$/, (m, a) => `Zu viele Versuche. Versuche es in ${a} s noch einmal.`],
  [/^Amélioration de la collection… (\d+)\/(\d+) \((\d+) retraitée\(s\)\)\. Tu peux continuer à utiliser l’appli\.$/,
    (m, a, b, c) => `Sammlung wird verbessert … ${a}/${b} (${c} neu verarbeitet). Du kannst die App weiter benutzen.`],
  [/^Amélioration en cours… (\d+)\/(\d+)$/, (m, a, b) => `Wird verbessert … ${a}/${b}`],
  [/^Collection améliorée : (\d+) image\(s\) retraitée\(s\), (\d+) laissée\(s\) telles quelles$/,
    (m, a, b) => `Sammlung verbessert: ${a} ${pl(a, "Bild", "Bilder")} neu verarbeitet, ${b} unverändert`],
  [/^Luminosité (\d+) sur (\d+) avec le capteur activé, ton un peu plus chaud, détecteur de présence moyen, mise en veille après 30 min\. Tu pourras tout changer ensuite\.$/,
    (m, a, b) => `Helligkeit ${a} von ${b} mit aktivem Sensor, etwas wärmerer Farbton, mittlerer Bewegungssensor, Ruhezustand nach 30 Min. Du kannst alles später ändern.`],
  [/^Plus froid, (\d+) sur (\d+)$/, (m, a, b) => `Kälter, ${a} von ${b}`],
  [/^Plus chaud, (\d+) sur (\d+)$/, (m, a, b) => `Wärmer, ${a} von ${b}`],
  [/^Plus lente \((.+) ×\)$/, (m, a) => `Langsamer (${a} ×)`],
  [/^Plus rapide \((.+) ×\)$/, (m, a) => `Schneller (${a} ×)`],
  [/^(\d+) min$/, (m, a) => `${a} Min.`],
  [/^(\d+) sur (\d+)$/, (m, a, b) => `${a} von ${b}`],
  [/^(.+) : fait$/, (m, a) => `${tr(a)}: erledigt`],
  [/^(\d+) sélections? masquées? · $/, (m, a) => `${a} ${pl(a, "Galerie", "Galerien")} ausgeblendet · `],
  [/^(\d+) sélections? masquées?$/, (m, a) => `${a} ${pl(a, "Galerie", "Galerien")} ausgeblendet`],
  [/^(.+) \(ma sélection\)$/, (m, a) => `${a} (meine Galerie)`],
  [/^Mots-clés : (.*)$/, (m, a) => `Stichwörter: ${a}`],
  [/^À découvrir : (.*)$/, (m, a) => `Zu entdecken: ${tr(a)}`],
  [/^(\d+) photos$/, (m, a) => `${a} Fotos`],
  [/^Photo (\d+)$/, (m, a) => `Foto ${a}`],
  [/^\+ (\d+)$/, (m, a) => `+ ${a}`],
  [/^(\d+) sur (\d+)…$/, (m, a, b) => `${a} von ${b} …`],
  [/^Envoi de la photo (\d+) sur (\d+)… Garde cette page ouverte\.$/, (m, a, b) => `Foto ${a} von ${b} wird gesendet … Lass diese Seite geöffnet.`],
  [/^(\d+) photos ajoutées dans « (.+) »$/, (m, a, b) => `${a} Fotos zu „${g(b.replace(" (neu)", ""))}“ hinzugefügt`],
  [/^Photo ajoutée dans « (.+) »$/, (m, a) => `Foto zu „${g(a.replace(" (neu)", ""))}“ hinzugefügt`],
  [/^(\d+) déjà dans ta collection$/, (m, a) => `${a} schon in deiner Sammlung`],
  [/^(\d+) n’ont pas pu être ajoutées$/, (m, a) => `${a} konnten nicht hinzugefügt werden`],
  [/^(.+)\. Vérifie que le Mac est allumé et réessaie\.$/, (m, a) => `${tr(a)}. Prüfe, ob der Mac eingeschaltet ist, und versuche es erneut.`],
  [/^Photo du (\d+) (\S+) (\d{4}) à (\d+)h(\d\d)( \d+)?$/, (m, j, mo, a, h, mi, n) => `Foto vom ${j}. ${MOIS_DE[MOIS_FR.indexOf(mo)] || mo} ${a}, ${h}.${mi} Uhr${n || ""}`],
  [/^(.+) \(nouveau\)$/, (m, a) => `${g(a)} (neu)`],
  [/^basse définition \((\d+) px\) : rendu un peu doux$/, (m, a) => `geringe Auflösung (${a} px): etwas weich`]
];
const MOIS_FR = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
const MOIS_DE = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];
function nomImage(fichier){ const n = fichier.replace(/\.jpe?g$/i, ""); const t = tr(n); return t === n ? fichier : t; }

// ---------- Menus de la TV : en allemand ou en anglais (choix dans l'assistant) ----------
const MENUS_EN = new Set(["Settings > All Settings > Picture", "Settings > All Settings > Sound", "Settings > All Settings", "Picture Mode", "Filmmaker",
  "Picture > Picture Mode", "Picture Clarity", "Picture > Expert Settings > Picture Clarity Settings", "Contrast Enhancer", "Low", "Picture > Expert Settings",
  "Colour Tone", "Brightness Optimization", "On", "Off", "General & Privacy > Power and Energy Saving", "Sound Output", "Receiver (Optical)", "Sound > Sound Output",
  "Digital Output Audio Format", "Sound > Expert Settings", "Simultaneous Optical Output", "Universal Remote",
  "Home > Connected Devices > Universal Remote Setup > Start > Home Theater", "Night Mode", "Home > Art > roue dentée", "Auto Update", "Support > Software Update",
  "TV Speaker", "Sound Mode", "Sound > Sound Mode", "Auto Volume"]);
const CLE_MENUS = "maframe-menus-tv";
const menusEN = () => { try{ return localStorage.getItem(CLE_MENUS) === "en"; }catch(e){ return false; } };
const INTRO_OPT = "Fais chaque réglage avec la télécommande, puis touche le rond pour le cocher. Les noms sont ceux des menus anglais de la TV.";
const introOpt = () => "Nimm jede Einstellung mit der Fernbedienung vor und tippe dann auf den Kreis, um sie abzuhaken. Die Namen entsprechen den " +
  (menusEN() ? "englischen" : "deutschen") + " Menüs deines Fernsehers.";
DE[INTRO_OPT] = introOpt();
DE["Home > Art > roue dentée"] = "Home > Art > Zahnrad";
function choisirMenus(l){
  try{ localStorage.setItem(CLE_MENUS, l); }catch(e){}
  DE[INTRO_OPT] = introOpt();
  document.querySelectorAll("#segMenus button").forEach(b => b.setAttribute("aria-checked", b.dataset.l === l));
  const intro = document.querySelector("#sheetOptim .intro"); if(intro) intro.textContent = introOpt();
  if(typeof window.dessinerOptim === "function") window.dessinerOptim();
}
window.choisirMenus = choisirMenus;
document.addEventListener("DOMContentLoaded", () => {
  const intro = document.querySelector("#sheetOptim .intro"); if(!intro) return;
  const seg = document.createElement("div");
  seg.className = "segSon segMenus"; seg.id = "segMenus"; seg.setAttribute("role", "radiogroup"); seg.setAttribute("aria-label", "Menüs des Fernsehers");
  seg.style.margin = "12px 16px 0";
  seg.innerHTML = [["de", "Fernseher auf Deutsch"], ["en", "Fernseher auf Englisch"]].map(([l, t]) =>
    `<button role="radio" data-l="${l}" aria-checked="${menusEN() === (l === "en")}" onclick="choisirMenus('${l}')">${t}</button>`).join("");
  intro.after(seg);
});

// ---------- Moteur de traduction ----------
const NOM_DE = "Meine FRAME";                                  // nom de l'appli en allemand
const manquants = new Set(); window.TEXTES_MANQUANTS = manquants;   // pour vérifier qu'aucun texte n'est oublié
const AUCUNE_LETTRE = /^[^A-Za-zÀ-ÿŒœ]*$/;
function tr(s){
  if(s == null) return s;
  const brut = String(s), k = brut.trim();
  if(!k || AUCUNE_LETTRE.test(k)) return s;
  if(MENUS_EN.has(k) && menusEN()) return s.replace(k, k.replace("roue dentée", "⚙"));
  let r = DE[k];
  if(r === undefined) for(const [re, f] of MOTIFS){ const m = k.match(re); if(m){ r = f(...m); break; } }
  if(r === undefined && k.includes(" · ")){                          // texte composé : chaque morceau à part
    const parts = k.split(" · "), t = parts.map(p => tr(p));
    if(t.some((x, i) => x !== parts[i])) r = t.join(" · ");
  }
  if(r === undefined && /[àâçéèêëîïôûùœ’«]/i.test(k)) manquants.add(k);
  const sortie = (r === undefined ? brut : brut.replace(k, r)).replace(/Ma Frame/g, NOM_DE);
  return sortie === brut ? s : sortie;
}
window.tr = tr;

const ATTRS = ["title", "aria-label", "placeholder", "alt", "aria-valuetext"];
const PAS_TOUCHE = "script,style,textarea,input,[translate=no]";
function traduireTexte(n){
  const p = n.parentElement; if(!p || p.closest(PAS_TOUCHE)) return;
  const v = n.nodeValue, t = tr(v); if(t !== v) n.nodeValue = t;
}
function traduireAttrs(el){
  for(const a of ATTRS){ const v = el.getAttribute(a); if(v){ const t = tr(v); if(t !== v) el.setAttribute(a, t); } }
}
function traduireArbre(racine){
  if(racine.nodeType === 3){ traduireTexte(racine); return; }
  if(racine.nodeType !== 1) return;
  if(racine.matches && racine.matches("script,style")) return;
  traduireAttrs(racine);
  const w = document.createTreeWalker(racine, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
  let n; while((n = w.nextNode())){ if(n.nodeType === 3) traduireTexte(n); else traduireAttrs(n); }
}
new MutationObserver(ms => {
  for(const m of ms){
    if(m.type === "childList") m.addedNodes.forEach(traduireArbre);
    else if(m.type === "characterData") traduireTexte(m.target);
    else if(m.type === "attributes") traduireAttrs(m.target);
  }
}).observe(document.documentElement, {subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS});
document.addEventListener("DOMContentLoaded", () => { traduireArbre(document.documentElement);
  document.querySelector('meta[name="apple-mobile-web-app-title"]')?.setAttribute("content", NOM_DE); });
// Version allemande : l'assistant « Optimiser » ne parle que du son de la TV (pas de barre de son)
try{ if(!localStorage.getItem("maframe-optim-son")) localStorage.setItem("maframe-optim-son", "tv"); }catch(e){}
document.head.appendChild(Object.assign(document.createElement("style"), {textContent: ".segSon:not(.segMenus){display:none!important}"}));

// ---------- Recherche en allemand ----------
// Collection (filtre local) : mot allemand sans accent → mots anglais/français présents dans les noms
window.SYN_DE = {schnee:"snow snowy winter hiver", winter:"winter snow hiver", sommer:"summer ete", fruhling:"spring blossom printemps", herbst:"autumn fall october automne",
  weihnachten:"christmas nativity noel", meer:"sea ocean seaside marine waves beach", strand:"beach seaside shore", welle:"wave waves", wellen:"waves wave",
  berg:"mountain mount peak", berge:"mountains mountain mount", blume:"flower blossom bloom", blumen:"flowers blossoms blossom", kirschblute:"cherry blossom",
  nacht:"night evening twilight", abend:"evening twilight sunset", sonnenuntergang:"sunset", sonne:"sun sunlight", brucke:"bridge", wald:"forest wood woods trees",
  baum:"tree", baume:"trees", see:"lake pond", fluss:"river stream", wasserfall:"waterfall falls", himmel:"sky", stern:"star stars", sterne:"stars milky",
  galaxie:"galaxy", nebel:"fog mist nebula", polarlicht:"aurora northern lights", nordlicht:"aurora northern lights", wuste:"desert dunes", gletscher:"glacier ice",
  stadt:"city town street", strasse:"street", hafen:"harbor port", boot:"boat boats ship", schiff:"ship boat", garten:"garden", seerosen:"water lily lilies",
  feld:"field", regen:"rain rainy", tiere:"wildlife animal bird", vogel:"bird birds", katze:"cat", hund:"dog", pferd:"horse", kirche:"church", landschaft:"landscape",
  dorf:"village", tempel:"temple shrine", japan:"japanese hokusai hiroshige edo fuji", weltraum:"space nasa galaxy nebula", fotos:"photo photos"};
// Ajouter (recherche dans les musées, en anglais) : mot allemand sans accent → anglais
window.DE_EN = {schnee:"snow",winter:"winter",sommer:"summer",fruhling:"spring",herbst:"autumn",weihnachten:"Christmas",meer:"sea",ozean:"ocean",strand:"beach",
  welle:"wave",wellen:"waves",berg:"mountain",berge:"mountains",blume:"flower",blumen:"flowers",kirschblute:"cherry blossom",kirschbluten:"cherry blossoms",nacht:"night",
  abend:"evening",sonnenuntergang:"sunset",sonne:"sun",brucke:"bridge",wald:"forest",baum:"tree",baume:"trees",see:"lake",fluss:"river",wasserfall:"waterfall",
  himmel:"sky",sterne:"stars",galaxie:"galaxy",nebel:"fog",polarlicht:"aurora",nordlicht:"aurora borealis",wuste:"desert",gletscher:"glacier",stadt:"city",
  strasse:"street",hafen:"harbor",boot:"boat",boote:"boats",schiff:"ship",schiffe:"ships",garten:"garden",seerosen:"water lilies",feld:"field",weizen:"wheat",
  regen:"rain",tiere:"animals",vogel:"bird",katze:"cat",katzen:"cats",hund:"dog",pferd:"horse",pferde:"horses",kirche:"church",landschaft:"landscape",
  portrat:"portrait",stillleben:"still life",venedig:"Venice",london:"London",mond:"moon",mondschein:"moonlight",tanz:"dance",musik:"music",karte:"map",
  karten:"maps",tempel:"temple",schloss:"castle",burg:"castle",leuchtturm:"lighthouse",dorf:"village",markt:"market",cafe:"cafe",kloster:"monastery",
  ruine:"ruin",ruinen:"ruins",kuste:"coast",insel:"island",alpen:"Alps",rhein:"Rhine",ostsee:"Baltic Sea",nordsee:"North Sea",nebelmeer:"sea of fog",
  wanderer:"wanderer",frau:"woman",mann:"man",kind:"child",kinder:"children",blau:"blue",rot:"red",grun:"green",gelb:"yellow",gold:"gold"};
})();
